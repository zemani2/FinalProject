# Garmin Partner Samples
A repository that contains a collection of projects and modules that demonstrate 
various aspects of what a Garmin partner would implement.

* `garmin-partner-model` - Generates client model objects for each of our 
APIs, uses the swagger yaml/json documentation and Swagger's client code generator. 
Can output client models for a variety of supported languages see https://swagger.io/tools/swagger-codegen/.
* `garmin-partner-common` - Common files used between multiple modules. Mainly involves database files.
* `garmin-partner-oauth` - Sample implementation for the 3 legged oauth 1 process, 
also demonstrates using the secrets to create the OAuth 1.0a header and execute the 
get user id endpoint.
* `garmin-partner-ping-api` - Sample implementations for Health, MCT, and Activity 
API pillars using the ping service. The activity file domain is not included since it is a unique implementation.
* `garmin-partner-push-api` - Sample implementations for Health, MCT, and Activity 
API pillars using the push service. The activity file domain is not included since it is a unique implementation.
* `garmin-partner-activity-file-api` - Sample implementation for the activity 
file api integration.
* `garmin-partner-backfill-api` - Sample implementation for any domain that has 
backfill support.
* `garmin-partner-workout-api` - Sample implementation for the workout api.
* `garmin-partner-course-api` - Sample implementation for the course api.

### How do I run a module in this project?
The main modules that can be run are the:
* `garmin-partner-ping-api` module
* `garmin-partner-push-api` module

1. In order to run these modules you simply need to run the following command in 
the parent module's folder (the root folder of the repository):
```
mvn clean install
```

This will run all of the nessacary Maven steps and will create .jar files for the modules in question.

2. Navigate to the `/"module"/target` (ex. `garmin-partner-ping-api/target`) folder and 
run the following command:
```
java -jar ________.jar  (ex. java -jar pingapi-0.0.1-SNAPSHOT.jar)
```

3. For more specific instructions on using the module read the `README.md` inside that modules folder.
