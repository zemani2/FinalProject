# Sample Push Implementation 
Sample implementations for Health, MCT, and Activity Api Pillars. The activity 
file domain is not included since it is a unique implmentation. The goal of this 
repository is to give partners a staring place to develop their own integrations with the
Garmin Health API if they decide to use the push service. This repository is also designed 
to help alleviate many common pitfalls that partners run into during their development.

## Requirements
* Java JDK 11
* Maven 3.8.1
* A valid evaluation app set up on [developerportal.garmin.com](https://developerportal.garmin.com)
with consumer key and consumer secret
* A test account created on [connecttest.garmin.com](https://connecttest.garmin.com)

## Installation
1. Clone the repository to your computer
2. Navigate to the parent repository
3. Run the following command:
    ```
    mvn clean package
    ```
4. Navigate into garmin-partner-push-api/target
5. Run the following command:
    ```
    java -jar pushapi-______.jar
    ```
Upon starting up the application it will create an in-memory H2 DB. This DB has the following info:
**URL**: jdbc:h2:mem:db
**Username**: partner-sample
**Password**: partner

## Using the sample
**If on localhost the default port number is 9000**
* In order to use the sample you must first create a test account on 
[connecttest.garmin.com](https://connecttest.garmin.com).
* Upon starting the program you must first navigate to `/consumer/setUpNewConsumer`
This endpoint will take you to a basic Thymeleaf webpage to enter in your consumer info:
    ```
    Consumer Key  (Your consumer key)
    ```
    ```
    Consumer Secret (Your consumer secret)
    ```
    ```
    Consumer Name (The name of the consumer in the DB)
    ```
* After successfully registering the consumer you will need to register a user to that consumer. 
Navigate to `/auth/requestToken`. This endpoint takes one query parameter:
    ```
    consumer_key (The consumer key you would like to register the user to)
    ```
This endpoint will take you to a webpage where you can login to your 
[connecttest.garmin.com](https://connecttest.garmin.com) account and 
create an OAuth token for the user.

* After the OAuth process is complete you will be redirected to a page that has your
user access token and user access token secret. Save this for sending data.

* In order to register more users with the consumer navigate to `/auth/requestToken?consumer_key=`. 
You will be prompted to sign into the account that you created on 
[connecttest.garmin.com](https://connecttest.garmin.com).

* You can use the data generation tool on the API tools webpage in order to generate some data for the 
user access token you were given. This data will automatically be uploaded to the endpoints that were 
configured in the API tools.

* You can also use your favorite POSTing tool such as cURL 
or Postman to hit the endpoints with a body formatted in the following way:
    ```
    {
        "epochs": [
            {
                "userId": "4aacafe82427c251df9c9592d0c06768",
                "userAccessToken": "e6ad054b-b1ad-4f00-a721-1bcd4733df2d",
                "summaryId": "500967853",
                "activityType": "WALKING",
                "activeKilocalories": 24,
                "steps": 93,
                "distanceInMeters": 49.11,
                "durationInSeconds": 840,
                "activeTimeInSeconds": 449,
                "startTimeInSeconds": 1519679700,
                "startTimeOffsetInSeconds": -21600,
                "met": 3.3020337,
                "intensity": "ACTIVE",
                "meanMotionIntensity": 4,
                "maxMotionIntensity": 7
            }
        ]
    }    
    ```
    (This body will hit the API with one epoch summary for the user with UAT: e6ad054b-b1ad-4f00-a721-1bcd4733df2d)

**You will need to replace the userAccessToken field with the correct user access token
for your test account on [connecttest.garmin.com](https://connecttest.garmin.com).**

## Valid Endpoints (For localhost the default port is 9000)
### Push Endpoints
* `/push/activities` (For retrieving activities data)
* `/push/activitydetails` (For retrieving activity detail data)
* `/push/manualactivityupdate` (For retrieving manually updated activities data)
* `/push/moveiq` (For retrieving moveiq data)
* `/push/bodycompositions` (For retrieving body composition data)
* `/push/dailies` (For retrieving dailies data)
* `/push/epochs` (For retrieving epoch data)
* `/push/pulseox` (For retrieving pulse ox data)
* `/push/respiration` (For retrieving respiration data)
* `/push/sleep` (For retrieving sleep data)
* `/push/stress` (For retrieving stress data)
* `/push/thirdpartydailies` (For retrieving third-party dailies data)
* `/push/usermetrics` (For retrieving user metric data)
* `/push/menstrualcycletracking` (For retrieving menstrual cycle tracking data)
       
### Backfill Endpoints (More information in the garmin-partner-backfill-api README)
* `/backfill/activities?uat=__&startTime=___&endTime=___`
* `/backfill/moveiq?uat=__&startTime=___&endTime=___`
* `/backfill/bodycompositions?uat=__&startTime=___&endTime=___`
* `/backfill/dailies?uat=__&startTime=___&endTime=___`
* `/backfill/epochs?uat=__&startTime=___&endTime=___`
* `/backfill/sleep?uat=__&startTime=___&endTime=___`
* `/backfill/stress?uat=__&startTime=___&endTime=___`
* `/backfill/usermetrics?uat=__&startTime=___&endTime=___`
* `/backfill/menstrualcycletracking?uat=__&startTime=___&endTime=___`

### OAuth Endpoints
* `/auth/requestToken?consumer_key=` (For registering a user to the consumer)

### Partner registering
* `/consumer/setUpNewPartner` (For initially registering consumers)
