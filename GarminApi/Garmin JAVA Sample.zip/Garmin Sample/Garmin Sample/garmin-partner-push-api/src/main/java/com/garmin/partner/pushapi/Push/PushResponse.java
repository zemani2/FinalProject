package com.garmin.partner.pushapi.Push;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.garmin.partner.common.Consts;
import java.util.HashMap;
import java.util.List;

/**
 * Object that represents the Json returned from the Push service
 *
 * @author Greg Heiman
 */
public class PushResponse {
    @JsonAlias({Consts.ACTIVITIES, Consts.DAILIES, Consts.THIRD_PARTY_DAILIES,
                Consts.EPOCHS, Consts.SLEEPS, Consts.BODYCOMPS, Consts.BLOODPRESSURES,
                Consts.ACTIVITYUPDATES, Consts.MOVEIQ, Consts.PULSEOX, Consts.MCT,
                Consts.ALL_DAY_RESPIRATION, Consts.STRESS, Consts.USERINFO,
                Consts.MCT, Consts.ACTIVITY_DETAILS, Consts.USERMETRICS})
    private List<HashMap<String, Object>> pushResponseBody;

    private String summaryTitle;

    public List<HashMap<String, Object>> getPushResponseBody() {
        return pushResponseBody;
    }

    public void setPushResponseBody(List<HashMap<String, Object>> pushResponseBody) {
        this.pushResponseBody = pushResponseBody;
    }

    public String getSummaryTitle() {
        return summaryTitle;
    }

    public void setSummaryTitle(String summaryTitle) {
        this.summaryTitle = summaryTitle;
    }

    @Override
    public String toString() {
        return ("summaryTitle=" + summaryTitle + "\n" + pushResponseBody.toString());
    }
}
