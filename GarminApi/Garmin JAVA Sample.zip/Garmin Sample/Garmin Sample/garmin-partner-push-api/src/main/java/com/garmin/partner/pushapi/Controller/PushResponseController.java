package com.garmin.partner.pushapi.Controller;

import com.garmin.partner.common.Consts;
import com.garmin.partner.pushapi.Push.PushResponse;
import com.garmin.partner.pushapi.Push.PushService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controls the endpoints for the Push service.
 *
 * @author Greg Heiman
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/push")
public class PushResponseController {
    private static final Logger log = LoggerFactory.getLogger(PushResponseController.class);

    @Autowired private PushService pushService;

    /** Test endpoint for the push service. Simply returns a message. */
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public String handleTestEndpoint() {
        return "Hello. This test endpoint is working";
    }

    /**
     * Manage the endpoint for activities. When the endpoints are POSTed to by the Garmin Health API
     * run through the updated entries and parse them out to PushResponse objects which will then be
     * handled by the PushService class.
     *
     * @param activity The body of the request will contain the JSON data
     */
    @RequestMapping(value = "/activities", method = RequestMethod.POST)
    public ResponseEntity<String> handleActivityPushNotification(
            @RequestBody PushResponse activity) {
        log.info("Activities endpoint push notification");
        activity.setSummaryTitle(Consts.ACTIVITIES);

        // Check to see if the PushResponse is not null
        if (activity != null
                && activity.getPushResponseBody() != null
                && activity.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(activity);
        } else {
            log.warn("Sending acknowledgment - 204 for activities push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/activitydetails", method = RequestMethod.POST)
    public ResponseEntity<String> handleActivityDetailPushNotification(
            @RequestBody PushResponse activityDetails) {
        log.info("Activity details endpoint push notification");
        activityDetails.setSummaryTitle(Consts.ACTIVITY_DETAILS);

        // Check to see if the PushResponse is not null
        if (activityDetails != null
                && activityDetails.getPushResponseBody() != null
                && activityDetails.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(activityDetails);
        } else {
            log.warn("Sending acknowledgment - 204 for activity details push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/manualactivityupdate", method = RequestMethod.POST)
    public ResponseEntity<String> handleManualActivityUpdatePushNotification(
            @RequestBody PushResponse manualActivityUpdate) {
        log.info("Manually updated activities endpoint push notification");
        manualActivityUpdate.setSummaryTitle(Consts.ACTIVITYUPDATES);

        // Check to see if the PushResponse is not null
        if (manualActivityUpdate != null
                && manualActivityUpdate.getPushResponseBody() != null
                && manualActivityUpdate.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(manualActivityUpdate);
        } else {
            log.warn(
                    "Sending acknowledgment - 204 for manually updated activities push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/moveiq", method = RequestMethod.POST)
    public ResponseEntity<String> handleMoveIqPushNotification(@RequestBody PushResponse moveIq) {
        log.info("MoveIQ endpoint push notification");
        moveIq.setSummaryTitle(Consts.MOVEIQ);

        // Check to see if the PushResponse is not null
        if (moveIq != null
                && moveIq.getPushResponseBody() != null
                && moveIq.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(moveIq);
        } else {
            log.warn("Sending acknowledgment - 204 for move iq push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/bodycompositions", method = RequestMethod.POST)
    public ResponseEntity<String> handleBodyCompositionsPushNotification(
            @RequestBody PushResponse bodyComp) {
        log.info("Body compositions endpoint push notification");
        bodyComp.setSummaryTitle(Consts.BODYCOMPS);

        // Check to see if the PushResponse is not null
        if (bodyComp != null
                && bodyComp.getPushResponseBody() != null
                && bodyComp.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(bodyComp);
        } else {
            log.warn(
                    "Sending acknowledgment - 204 for body compositions push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/dailies", method = RequestMethod.POST)
    public ResponseEntity<String> handleDailiesPushNotification(@RequestBody PushResponse dailies) {
        log.info("Dailies endpoint push notification");
        dailies.setSummaryTitle(Consts.DAILIES);

        // Check to see if the PushResponse is not null
        if (dailies != null
                && dailies.getPushResponseBody() != null
                && dailies.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(dailies);
        } else {
            log.warn("Sending acknowledgment - 204 for dailies push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/epochs", method = RequestMethod.POST)
    public ResponseEntity<String> handleEpochPushNotification(@RequestBody PushResponse epochs) {
        log.info("Epochs endpoint push notification");
        epochs.setSummaryTitle(Consts.EPOCHS);

        // Check to see if the PushResponse is not null
        if (epochs != null
                && epochs.getPushResponseBody() != null
                && epochs.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(epochs);
        } else {
            log.warn("Sending acknowledgment - 204 for epochs push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/pulseox", method = RequestMethod.POST)
    public ResponseEntity<String> handlePulseOxPushNotification(@RequestBody PushResponse pulseox) {
        log.info("Pulse ox endpoint push notification");
        pulseox.setSummaryTitle(Consts.PULSEOX);

        // Check to see if the PushResponse is not null
        if (pulseox != null
                && pulseox.getPushResponseBody() != null
                && pulseox.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(pulseox);
        } else {
            log.warn("Sending acknowledgment - 204 for pulse ox push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/respiration", method = RequestMethod.POST)
    public ResponseEntity<String> handleRespirationPushNotification(
            @RequestBody PushResponse respiration) {
        log.info("Respiration endpoint push notification");
        respiration.setSummaryTitle(Consts.ALL_DAY_RESPIRATION);

        // Check to see if the PushResponse is not null
        if (respiration != null
                && respiration.getPushResponseBody() != null
                && respiration.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(respiration);
        } else {
            log.warn("Sending acknowledgment - 204 for respiration push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/sleep", method = RequestMethod.POST)
    public ResponseEntity<String> handleSleepPushNotification(@RequestBody PushResponse sleep) {
        log.info("Sleep endpoint push notification");
        sleep.setSummaryTitle(Consts.SLEEPS);

        // Check to see if the PushResponse is not null
        if (sleep != null
                && sleep.getPushResponseBody() != null
                && sleep.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(sleep);
        } else {
            log.warn("Sending acknowledgment - 204 for sleep push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/stress", method = RequestMethod.POST)
    public ResponseEntity<String> handleStressPushNotification(@RequestBody PushResponse stress) {
        log.info("Stress endpoint push notification");
        stress.setSummaryTitle(Consts.STRESS);

        // Check to see if the PushResponse is not null
        if (stress != null
                && stress.getPushResponseBody() != null
                && stress.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(stress);
        } else {
            log.warn("Sending acknowledgment - 204 for stress push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/thirdpartydailies", method = RequestMethod.POST)
    public ResponseEntity<String> handleThirdPartyDailiesPushNotification(
            @RequestBody PushResponse thirdPartyDailies) {
        log.info("Third-party dailies endpoint push notification");
        thirdPartyDailies.setSummaryTitle(Consts.THIRD_PARTY_DAILIES);

        // Check to see if the PushResponse is not null
        if (thirdPartyDailies != null
                && thirdPartyDailies.getPushResponseBody() != null
                && thirdPartyDailies.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(thirdPartyDailies);
        } else {
            log.warn(
                    "Sending acknowledgment - 204 for third-party dailies push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/usermetrics", method = RequestMethod.POST)
    public ResponseEntity<String> handleUserMetricsPushNotification(
            @RequestBody PushResponse userMetrics) {
        log.info("User metrics endpoint push notification");
        userMetrics.setSummaryTitle(Consts.USERMETRICS);

        // Check to see if the PushResponse is not null
        if (userMetrics != null
                && userMetrics.getPushResponseBody() != null
                && userMetrics.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(userMetrics);
        } else {
            log.warn("Sending acknowledgment - 204 for user metrics push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    @RequestMapping(value = "/menstrualcycletracking", method = RequestMethod.POST)
    public ResponseEntity<String> handleMenstrualCycleTrackingPushNotification(
            @RequestBody PushResponse menstrualCycle) {
        log.info("Menstrual cycle tracking endpoint push notification");
        menstrualCycle.setSummaryTitle(Consts.MCT);

        // Check to see if the PushResponse is not null
        if (menstrualCycle != null
                && menstrualCycle.getPushResponseBody() != null
                && menstrualCycle.getPushResponseBody().size() > 0) {
            // Hit the callback URL's
            return pushService.handlePush(menstrualCycle);
        } else {
            log.warn(
                    "Sending acknowledgment - 204 for menstrual cycle tracking push notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }
}
