package com.garmin.partner.pushapi.Push;

import com.garmin.partner.common.models.SummaryData;
import com.garmin.partner.common.models.UserAccessToken;
import com.garmin.partner.common.services.SummaryDataService;
import com.garmin.partner.common.services.UserAccessTokenService;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * Service that manages the processing of the data that is returned to the Push service endpoints
 *
 * @author Greg Heiman
 */
@Service
public class PushService {
    private static final Logger log = LoggerFactory.getLogger(PushService.class);

    private SummaryData summaryData = new SummaryData();
    private UserAccessToken userAccessToken = new UserAccessToken();
    private String summaryDomain;

    @Autowired private SummaryDataService summaryDataService;
    @Autowired private UserAccessTokenService userAccessTokenService;
    @Autowired private SessionFactory sessionFactory;

    /**
     * Convert each push response into a {@link SummaryData} object.
     *
     * @param json a hashmap of type <String, Object> that represents the {@link PushResponse} json
     *     as a map.
     * @return a {@link SummaryData} object.
     */
    private SummaryData convertPushResponseToSummaryDataObject(HashMap<String, Object> json) {
        SummaryData summaryData = new SummaryData();

        summaryData.setStartTime(Long.valueOf(json.get("startTimeInSeconds").toString()));
        summaryData.setDuration(Long.valueOf(json.get("durationInSeconds").toString()));
        summaryData.setCalendarDate(
                summaryData.formatDate(Long.valueOf(json.get("startTimeInSeconds").toString())));
        summaryData.setSummaryDomain(summaryDomain);
        summaryData.setSummaryId(json.get("summaryId").toString());

        // Find the User ID from the token that was included in the Push notification
        userAccessToken.setUat(json.get("userAccessToken").toString());
        Long userId = userAccessTokenService.findByUat(userAccessToken).getUserId();
        summaryData.setUserId(userId);

        try {
            summaryData.setSummaryDataLob(summaryData.setBlobBytes(json));
        } catch (SQLException se) {
            log.error(
                    "There was an error setting the lob data from the callback url. "
                            + se.getMessage());
        }

        return summaryData;
    }

    /**
     * Create an arraylist of summary data from the push notification
     *
     * @param push a {@link PushResponse} from the Garmin API.
     * @return a {@link ResponseEntity} with {@link HttpStatus} 200 if successful, 400 otherwise.
     */
    public ResponseEntity<String> handlePush(PushResponse push) {
        summaryDomain = push.getSummaryTitle();
        ArrayList<SummaryData> summaryList = new ArrayList<SummaryData>();

        // For each push response in the push notification convert the json to a
        // SummaryData object
        // and add the object to a list of SummaryData objects
        for (HashMap<String, Object> pushMap : push.getPushResponseBody()) {
            summaryList.add(convertPushResponseToSummaryDataObject(pushMap));
        }

        if (summaryList.size() != 0 && summaryList != null) {
            // Attempt to place the list of SummaryData into the DB
            if (placeSummaryDataIntoDB(summaryList)) {
                return new ResponseEntity<String>(HttpStatus.OK);
            } else {
                return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else {
            log.error("Summary list is empty. Cannot place empty list into DB.");
            return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Open up a session and a transaction to place the summaries into the DB.
     *
     * @param summaries an {@link ArrayList} summaries that will be placed into the DB.
     * @return {@link Boolean} true if the transaction was successful, false otherwise.
     */
    private boolean placeSummaryDataIntoDB(ArrayList<SummaryData> summaries) {
        Session session;
        // Try to obtain a session or open a session up
        try {
            session = sessionFactory.getCurrentSession();
        } catch (HibernateException e) {
            log.warn("No session found. Attempting to open a new session.");
            session = sessionFactory.openSession();
        }

        session.getTransaction().begin();

        // Add each of the summaries to the transaction
        long sessionLengthCounter = 0;
        for (SummaryData summary : summaries) {
            if (summaryDataService.verifyUniqueSummaryId(summary)) {
                session.save(summary);
                sessionLengthCounter++;
            } else {
                log.warn(
                        "Duplicate summary ID: "
                                + summary.getSummaryId()
                                + " will not place duplicates into DB.");
            }
        }

        boolean successful = false;
        try {
            // Commit the transaction
            session.getTransaction().commit();
            successful = true;
        } catch (HibernateException he) {
            if (session.getTransaction() != null) {
                // Rollback the transaction if there is an error
                session.getTransaction().rollback();
            }
            log.error(
                    "There was an error commiting the transaction to the DB.\n" + he.getMessage());
        } finally {
            session.close();
        }

        // Return whether the transaction was successful
        if (successful) {
            log.info(
                    "Transaction was commited successfully. Transaction contained "
                            + sessionLengthCounter
                            + " entries.");
            return true;
        } else {
            log.warn("Could not verify if transaction was commited.");
            return false;
        }
    }
}
