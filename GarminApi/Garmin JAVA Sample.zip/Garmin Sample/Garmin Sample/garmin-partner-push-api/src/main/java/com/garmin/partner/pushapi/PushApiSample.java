package com.garmin.partner.pushapi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Sample implementation of the Push service for the Garmin API.
 *
 * @author Greg Heiman
 */
@SpringBootApplication(
        scanBasePackages = "com.garmin.partner",
        exclude = HibernateJpaAutoConfiguration.class)
@EntityScan(basePackages = "com.garmin.partner.common")
@EnableJpaRepositories(basePackages = "com.garmin.partner.common")
public class PushApiSample {
    private static final Logger log = LoggerFactory.getLogger(PushApiSample.class);

    public static void main(String[] args) {
        SpringApplication.run(PushApiSample.class, args);
    }

    @Bean
    public CommandLineRunner run() throws Exception {
        return args -> {
            log.info("Program started.");
        };
    }
}
