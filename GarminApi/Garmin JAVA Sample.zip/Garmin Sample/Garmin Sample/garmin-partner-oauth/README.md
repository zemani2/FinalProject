Sample implementation for the 3 legged oauth 1 process, also demonstrates using the secrets to create the oauth1 header and execute the get user id endpoint.

# TODO: Steps to run the project 




