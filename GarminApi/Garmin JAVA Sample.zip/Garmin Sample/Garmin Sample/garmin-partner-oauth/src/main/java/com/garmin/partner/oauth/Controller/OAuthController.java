package com.garmin.partner.oauth.Controller;

import com.garmin.partner.common.models.Partner;
import com.garmin.partner.common.models.User;
import com.garmin.partner.common.models.UserAccessToken;
import com.garmin.partner.common.services.PartnerService;
import com.garmin.partner.common.services.UserAccessTokenService;
import com.garmin.partner.common.services.UserService;
import com.garmin.partner.oauth.OAuthImpl;
import com.github.scribejava.core.model.OAuth1AccessToken;
import com.github.scribejava.core.model.OAuth1RequestToken;
import java.net.URI;
import java.net.URISyntaxException;
import javax.servlet.http.HttpServletRequest;
import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller class for the OAuth endpoints. These endpoints are used to
 * register users to consumers in the DB. This is a crucial step in order to be
 * able to send valid OAuth headers to the Garmin API.
 *
 * @author Greg Heiman
 */
@EnableAutoConfiguration
@RestController
@RequestMapping("/auth")
public class OAuthController {
    private static final Logger log = LoggerFactory.getLogger(OAuthController.class);
    private User user = new User();
    private UserAccessToken userAccessToken = new UserAccessToken();

    @Autowired
    private OAuthImpl oAuthImpl;
    @Autowired
    private UserService userService;
    @Autowired
    private PartnerService partnerService;
    @Autowired
    private UserAccessTokenService userAccessTokenService;

    /**
     * The first leg of the OAuth process.
     *
     * @param request HttpServletRequest that is used to build the callback url
     *                based on the URL of the request to this endpoint.
     */
    @RequestMapping(value = "/requestToken", method = RequestMethod.GET)
    public ResponseEntity<Object> oauthRequestToken(@RequestParam(value = "consumer_key") String consumerKey,
            HttpServletRequest request) throws Exception {
        ResponseEntity<Object> responseObject = null;
        Partner partner = new Partner();

        // Create a partner object with the provided consumer key
        partner.setConsumerKey(consumerKey);
        partner = partnerService.findByConsumerKey(partner);

        // Use the newly found partner object to create an OAuth service
        try {
            oAuthImpl.setService(partner.getConsumerKey(), partner.getConsumerSecret());
        } catch (NullPointerException npe) {
            log.error("There was an error creating an OAuth service using the  provided consumer key "
                    + "for the /auth/requestToken "
                      + "endpoint. Ensure that the provided consumer key is present in the DB.");
            return new ResponseEntity<Object>("Could not complete OAuth process. Ensure that the provided "
                    + "consumer key is present in the DB.", HttpStatus.BAD_REQUEST);
        }

        oAuthImpl.setConsumerKey(partner.getConsumerKey());
        oAuthImpl.setConsumerSecret(partner.getConsumerSecret());

        try {
            // Obtain the request token from the newly created service
            oAuthImpl.setRequestToken(oAuthImpl.getService().getRequestToken());
            log.info("The request token is: " + oAuthImpl.getRequestToken().toString());
        } catch (NullPointerException npe) {
            log.error("There was an error in obtaining the request token from the oauth service.\n"
                    + npe.getMessage());
            npe.printStackTrace();
            return new ResponseEntity<Object>("Could not obtain request token from oauth service.",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (oAuthImpl.getRequestToken() != null) {
            // Return a response object with the step 2 url attached
            responseObject = oauthConfirm(oAuthImpl.getRequestToken(), request.getRequestURL().toString());
        }

        return responseObject;
    }

    /**
     * The second leg of the OAuth process.
     *
     * @param oauthRequestToken the request token from the first leg of the OAuth
     *                          process
     * @param host              the name of the host service that called the request
     *                          token endpoint. Used to build the callback URL.
     * @return a response entity with headers attached that have the callback url
     *         for the /accessToken endpoint
     */
    public ResponseEntity<Object> oauthConfirm(OAuth1RequestToken oauthRequestToken, String host) {
        String oauthConfirmUrl = oAuthImpl.getService().getAuthorizationUrl(oauthRequestToken);
        HttpHeaders httpHeaders = new HttpHeaders();

        try {
            URIBuilder b = new URIBuilder(oauthConfirmUrl);
            b.addParameter("oauth_callback", buildThirdLegUrl(host).toString());
            URI uri = b.build();
            httpHeaders.setLocation(uri);
        } catch (URISyntaxException e) {
            log.error("URI syntax error: " + e.getMessage());
        }

        return new ResponseEntity<>(httpHeaders, HttpStatus.SEE_OTHER);
    }

    /**
     * Builds a custom callbackURL based on the host that hit the /requestToken
     * endpoint.
     *
     * @param host the hostname of the service that first called the /requestToken
     *             endpoint
     * @return the URI that points to the /accessToken endpoint with the proper
     *         hostname
     */
    private URI buildThirdLegUrl(String host) throws URISyntaxException {
        URIBuilder builder = new URIBuilder(host);
        builder.getHost();
        builder.setPathSegments("auth", "accessToken");

        return builder.build();
    }

    /**
     * The third leg of the OAuth process.
     *
     * @param oauthToken    query parameter that is the request token in string form
     * @param oauthVerifier query parameter that is the oauth verifier in string
     *                      form
     * @return message to user that says they have complete the OAuth process
     */
    @RequestMapping("/accessToken")
    public String oauthAccessToken(@RequestParam(value = "oauth_token") String oauthToken,
            @RequestParam(value = "oauth_verifier") String oauthVerifier) throws Exception {
        if (oauthVerifier != null && !oauthVerifier.isEmpty()) {
            OAuth1RequestToken token = new OAuth1RequestToken(oauthToken, oAuthImpl.getRequestToken().getTokenSecret());
            OAuth1AccessToken accessToken = oAuthImpl.getService().getAccessToken(token, oauthVerifier);
            createUserInDB(accessToken);

            return ("You have successfully completed the OAuth process.<br>" + "User Access Token: "
                    + accessToken.getToken() + "<br>" + "User Access Token Secret: " + accessToken.getTokenSecret());
        } else {
            return "There was an error in the OAuth process.";
        }
    }

    /**
     * Will add the UAT and UAT secret from OAuth to the user_access_token DB.
     * Attaches all of this information to a parter_id in the partner table. Will
     * generate a random UUID for the partner_user_acct_id field. Do not do this in
     * your program. Instead include the correct identifier for the user on the
     * partner's end
     *
     * @param accessToken the access token acquired from the OAuth process
     */
    private void createUserInDB(OAuth1AccessToken accessToken) {
        // Set the partner ID
        Partner partner = new Partner();
        partner.setConsumerKey(oAuthImpl.getConsumerKey());
        partner = partnerService.findByConsumerKey(partner);
        Long partnerId = partner.getPartnerID();
        user.setPartnerId(partnerId);

        // Generate a random UUID for the partnerUserAcctId
        user.setPartnerUserAcctId(User.generatePartnerUserAcctId());
        // Places that user entry into the User table
        userService.saveUser(user);

        // Creates an entry in the User table without gcps_user_acct_id
        userAccessToken.setUat(accessToken.getToken());
        userAccessToken.setUatSecret(accessToken.getTokenSecret());
        userAccessToken.setUserId(user.getUserId());

        // Verify that the UAT is unique before placing into the DB
        if (userAccessTokenService.verifyUniqueUserAccessToken(userAccessToken)) {
            // Place the UAT and UAT secret into the user_access_token table
            userAccessTokenService.saveUserAccessToken(userAccessToken);
            log.info("User access token: " + userAccessToken.getUat() + " and user access token secret: "
                    + userAccessToken.getUatSecret() + " where added for partner: " + partner.getConsumerKey());
        } else {
            log.warn("UAT: " + accessToken.getToken() + " is already present"
                    + " in the DB. Will not put duplicate UATs.");
        }
    }
}
