package com.garmin.partner.oauth.Controller;

import com.garmin.partner.common.models.Partner;
import com.garmin.partner.common.services.PartnerService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Controller class for the consumer endpoints. These endpoints are used to set
 * up new consumers in the DB as well as log into consumers that have already
 * been placed into the DB for OAuth verification.
 *
 * @author Greg Heiman
 */
@Controller
@RequestMapping("/consumer")
public class ConsumerController {
    private static final Logger log = LoggerFactory.getLogger(ConsumerController.class);
    private Partner partner = new Partner();
    @Autowired
    private PartnerService partnerService;

    /**
     * Endpoint to allow user to set up new partner if one doesn't already exist.
     *
     * @param consumerKey query parameter that corresponds to the user's consumer key they would
     *     like to set up
     * @param consumerSecret query parameter that corresponds to the user's consumer secret they
     *     would like to set up in the DB
     * @param consumerName query parameter that corresponds to the name of the consumer in the DB
     *     after it is created
     * @return ResponseEntity that redirects the user to the /consumer/login URL automatically so
     *     that the user doesn't need to hit that endpoint with the consumer they just set up
     */
    @RequestMapping(value = "/setUpNewPartner", method = RequestMethod.POST)
    public String setUpNewPartnerSubmit(@ModelAttribute Partner partner, Model model) throws Exception {
        model.addAttribute("partner", partner);

        // Ensure the partner is unique
        if (partnerService.verifyUniqueConsumerKey(partner)) {
            // Place the partner into the DB
            partnerService.savePartner(partner);
            log.info("The following partner was successfully placed into the DB:\n" + partner.toString());
            return "result";
        } else {
            log.warn("The following partner was not placed into the DB successfully:\n" + partner.toString() + "\n"
                    + "Ensure that the submitted partner was not a duplicate of an existing " + "partner in the DB.");
            return "setUpPartnerError";
        }
    }

    /**
     * Endpoint that presents users with a form to submit a new partner to the DB.
     * 
     * @param a {@link Model}
     * @return redirect to the result page upon submitting
     */
    @RequestMapping(value = "/setUpNewPartner", method = RequestMethod.GET)
    public String setUpNewPartnerForm(Model model) throws Exception {
        model.addAttribute("partner", new Partner());
        return "partner";
    }
}
