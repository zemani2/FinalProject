package com.garmin.partner.oauth;

import com.github.scribejava.core.builder.ServiceBuilder;
import com.github.scribejava.core.model.OAuth1AccessToken;
import com.github.scribejava.core.model.OAuth1RequestToken;
import com.github.scribejava.core.model.OAuthRequest;
import com.github.scribejava.core.model.Verb;
import com.github.scribejava.core.oauth.OAuth10aService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Implementation of the OAuth 1.0a service
 *
 * @author Greg Heiman
 */
@Component
public class OAuthImpl {
    private static final Logger log = LoggerFactory.getLogger(OAuthImpl.class);

    private String CONSUMER_KEY;
    private String CONSUMER_SECRET;

    private OAuth10aService service;
    private OAuth1RequestToken requestToken;
    private String verifier;
    private OAuth1AccessToken accessToken;
    private OAuthRequest request;

    // Set the oauth values from the properties file for the
    // selected profile
    @Value("${oauthrequesttoken.url}")
    private String oauthRequestTokenUrl;
    @Value("${oauthconfirm.url}")
    private String oauthConfirmUrl;
    @Value("${oauthaccesstoken.url}")
    private String oauthAccessTokenUrl;
    
    public void setService(String consumerKey, String consumerSecret) {
        log.info("The OAuth first leg URL is: " + oauthRequestTokenUrl);
        log.info("The OAuth second leg URL is: " + oauthConfirmUrl);
        log.info("The OAuth third leg URL is: " + oauthAccessTokenUrl);

        service = new ServiceBuilder(consumerKey)
                        .apiSecret(consumerSecret)
                        .build(new GarminApi(oauthRequestTokenUrl, oauthConfirmUrl, oauthAccessTokenUrl));
    }

    public OAuth10aService getService() {
        return service;
    }

    public void setRequestToken(OAuth1RequestToken requestToken) {
        this.requestToken = requestToken;
    }

    public OAuth1RequestToken getRequestToken() {
        return requestToken;
    }

    public void setVerifer(String verifier) {
        this.verifier = verifier;
    }

    public String getVerifier() {
        return verifier;
    }

    public void setAccessToken(OAuth1AccessToken accessToken) {
        this.accessToken = accessToken;
    }

    public OAuth1AccessToken getAccessToken() {
        return accessToken;
    }

    public String getConsumerKey() {
        return CONSUMER_KEY;
    }

    public void setConsumerKey(String CONSUMER_KEY) {
        this.CONSUMER_KEY = CONSUMER_KEY;
    }

    public String getConsumerSecret() {
        return CONSUMER_SECRET;
    }

    public void setConsumerSecret(String CONSUMER_SECRET) {
        this.CONSUMER_SECRET = CONSUMER_SECRET;
    }

    public void setRequest(OAuthRequest request) {
        this.request = request;
    }

    public OAuthRequest getRequest() {
        return request;
    }

    public OAuthRequest createOAuthGetRequest(String requestUrl) {
        // Create new OAuthRequest with the supplied url
        OAuthRequest oAuthRequest = new OAuthRequest(Verb.GET, requestUrl);
        setRequest(oAuthRequest);

        return oAuthRequest;
    }

    public OAuthRequest createOAuthDeleteRequest(String requestUrl) {
        // Create new OAuthRequest with the supplied url
        OAuthRequest oAuthRequest = new OAuthRequest(Verb.DELETE, requestUrl);
        setRequest(oAuthRequest);

        return oAuthRequest;
    }

    public OAuth1AccessToken createOAuthAccessToken(String uat, String uatSecret) {
        // Create new OAuth1AccessToken with the supplied UAT and UAT secret
        OAuth1AccessToken oAuth1AccessToken = new OAuth1AccessToken(uat, uatSecret);
        setAccessToken(oAuth1AccessToken);

        return oAuth1AccessToken;
    }
}
