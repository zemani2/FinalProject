package com.garmin.partner.oauth;

import com.github.scribejava.core.builder.api.DefaultApi10a;
import com.github.scribejava.core.model.OAuth1RequestToken;

/**
 * Extend the default OAuth 1.0a implementation from ScribeJava for the Garmin OAuth API.
 *
 * @author Greg Heiman
 */
public class GarminApi extends DefaultApi10a {
    private final String oauthRequestTokenUrl;
    private final String oauthConfirmUrl;
    private final String oauthAccessTokenUrl;

    protected GarminApi(String oauthRequstTokenUrl, String oauthConfirmUrl, String oauthAccessTokenUrl) {
        this.oauthRequestTokenUrl = oauthRequstTokenUrl;
        this.oauthConfirmUrl = oauthConfirmUrl;
        this.oauthAccessTokenUrl = oauthAccessTokenUrl;
    }        

    @Override
    public String getAccessTokenEndpoint() {
        return oauthAccessTokenUrl;
    }

    @Override
    public String getRequestTokenEndpoint() {
        return oauthRequestTokenUrl;
    }

    @Override
    public String getAuthorizationBaseUrl() {
        return oauthConfirmUrl;
    }

    @Override
    public String getAuthorizationUrl(OAuth1RequestToken requestToken) {
        return String.format(oauthConfirmUrl, requestToken.getToken());
    }
}
