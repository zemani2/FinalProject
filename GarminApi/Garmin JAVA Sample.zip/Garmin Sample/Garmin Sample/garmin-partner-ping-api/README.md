# Sample Ping Implementation 
Sample implementations for Health, MCT, and Activity Api Pillars. The activity 
file domain is not included since it is a unique implmentation. The goal of this 
repository is to give partners a staring place to develop their own integrations with the
Garmin Health API if they decide to use the ping service. This repository is also designed 
to help alleviate many common pitfalls that partners run into during their development.

## Requirements
* Java JDK 11
* Maven 3.8.1
* A valid evaluation app set up on [developerportal.garmin.com](https://developerportal.garmin.com)
with consumer key and consumer secret
* A test account created on [connecttest.garmin.com](https://connecttest.garmin.com)

## Installation
1. Clone the repository to your computer
2. Navigate to the parent repository
3. Run the following command:
    ```
    mvn clean package
    ```
4. Navigate into garmin-partner-ping-api/target
5. Run the following command:
    ```
    java -jar pingapi-______.jar
    ```
Upon starting up the application it will create an in-memory H2 DB. This DB has the following info:
**URL**: jdbc:h2:mem:db
**Username**: partner-sample
**Password**: partner

## Using the sample
**If on localhost the default port number is 9000**
* In order to use the sample you must first create a test account on 
[connecttest.garmin.com](https://connecttest.garmin.com).
* Upon starting the program you must first navigate to `/consumer/setUpNewConsumer`
This endpoint will take you to a basic Thymeleaf webpage to enter in your consumer info:
    ```
    Consumer Key  (Your consumer key)
    ```
    ```
    Consumer Secret (Your consumer secret)
    ```
    ```
    Consumer Name (The name of the consumer in the DB)
    ```
* After successfully registering the consumer you will need to register a user to that consumer. 
Navigate to `/auth/requestToken`. This endpoint takes one query parameter:
    ```
    consumer_key (The consumer key you would like to register the user to)
    ```
This endpoint will take you to a webpage where you can login to your 
[connecttest.garmin.com](https://connecttest.garmin.com) account and 
create an OAuth token for the user.

* After the OAuth process is complete you will be redirected to a page that has your
user access token and user access token secret. Save this for sending data.

* In order to register more users with the consumer navigate to `/auth/requestToken?consumer_key=`. 
You will be prompted to sign into the account that you created on 
[connecttest.garmin.com](https://connecttest.garmin.com).

* You can use the data generation tool on the API tools webpage in order to generate some data for the 
user access token you were given. This data will automatically be uploaded to the endpoints that were 
configured in the API tools.

* You can also use your favorite POSTing tool such as cURL 
or Postman to hit the endpoints with a body formatted in the following way:
    ```
    {
        "activities": [
            {
                "userId": "4aacafe82427c251df9c9592d0c06768",
                "userAccessToken": "a9adab3s-b7c8-4df1-93cf-28de0d92ef00",
                "uploadStartTimeInSeconds": 1621971698,
                "uploadEndTimeInSeconds": 1622058098,
                "callbackURL": "https://healthapitest.garmin.com/wellness-api/rest/activities?uploadStartTimeInSeconds=1623201800&uploadEndTimeInSeconds=1623255970"
            }
        ]
    }
    ```
    (This body will prompt the API to fetch all activity data from uploadStartTimeInSeconds
    to uploadEndTimeInSeconds for the user that is registered to that userAccessToken)

**You will need to replace the userAccessToken field with the correct user access token
for your test account on [connecttest.garmin.com](https://connecttest.garmin.com). 
You will also need to change the uploadStartTimeInSeconds and uploadEndTimeInSeconds
to match the times when you uploaded your test data to [connecttest.garmin.com](https://connecttest.garmin.com).**

## Valid Endpoints (For localhost the default port is 9000)
### Ping Endpoints
* `/ping/activities` (For retrieving activities data)
* `/ping/activitydetails` (For retrieving activity detail data)
* `/ping/manualactivityupdate` (For retrieving manually updated activities data)
* `/ping/moveiq` (For retrieving moveiq data)
* `/ping/bodycompositions` (For retrieving body composition data)
* `/ping/dailies` (For retrieving dailies data)
* `/ping/epochs` (For retrieving epoch data)
* `/ping/pulseox` (For retrieving pulse ox data)
* `/ping/respiration` (For retrieving respiration data)
* `/ping/sleep` (For retrieving sleep data)
* `/ping/stress` (For retrieving stress data)
* `/ping/thirdpartydailies` (For retrieving third-party dailies data)
* `/ping/usermetrics` (For retrieving user metric data)
* `/ping/menstrualcycletracking` (For retrieving menstrual cycle tracking data)
       
### Backfill Endpoints (More information in the garmin-partner-backfill-api README)
* `/backfill/activities?uat=__&startTime=___&endTime=___`
* `/backfill/moveiq?uat=__&startTime=___&endTime=___`
* `/backfill/bodycompositions?uat=__&startTime=___&endTime=___`
* `/backfill/dailies?uat=__&startTime=___&endTime=___`
* `/backfill/epochs?uat=__&startTime=___&endTime=___`
* `/backfill/sleep?uat=__&startTime=___&endTime=___`
* `/backfill/stress?uat=__&startTime=___&endTime=___`
* `/backfill/usermetrics?uat=__&startTime=___&endTime=___`
* `/backfill/menstrualcycletracking?uat=__&startTime=___&endTime=___`

### OAuth Endpoints
* `/auth/requestToken?consumer_key=` (For registering a user to the consumer)

### Partner registering
* `/consumer/setUpNewPartner` (For initially registering consumers)
