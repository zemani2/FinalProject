package com.garmin.partner.pingapi.Controller;

import com.garmin.partner.common.Consts;
import com.garmin.partner.pingapi.Ping.PingResponse;
import com.garmin.partner.pingapi.Ping.PingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controls the endpoints for the Ping/Pull service.
 * When the endpoints are POSTed to by the Garmin Health API
 * run through the updated entries and parse them out to PingResponse objects which will then be
 * handled by the PingSerivce class.
 *
 * @author Greg Heiman
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/ping")
public class PingResponseController {
    private static final Logger log = LoggerFactory.getLogger(PingResponseController.class);

    @Autowired private PingService pingService;

    /** Test endpoint for the ping service. Simply returns a message. */
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public String handleTestEndpoint() {
        return "Hello. This test endpoint is working";
    }

    @RequestMapping(value = "/activities", method = RequestMethod.POST)
    public ResponseEntity<String> handleActivityPingNotification(
            @RequestBody PingResponse activity) {
        log.info("Activities endpoint ping notification");
        activity.setSummaryTitle(Consts.ACTIVITIES);

        return pingService.sendAppropriateResonseToGarminApi(activity);
    }

    @RequestMapping(value = "/activitydetails", method = RequestMethod.POST)
    public ResponseEntity<String> handleActivityDetailPingNotification(
            @RequestBody PingResponse activityDetails) {
        log.info("Activity details endpoint ping notification");
        activityDetails.setSummaryTitle(Consts.ACTIVITY_DETAILS);

        return pingService.sendAppropriateResonseToGarminApi(activityDetails);
    }

    @RequestMapping(value = "/manualactivityupdate", method = RequestMethod.POST)
    public ResponseEntity<String> handleManualActivityUpdatePingNotification(
            @RequestBody PingResponse manualActivityUpdate) {
        log.info("Manually updated activities endpoint ping notification");
        manualActivityUpdate.setSummaryTitle(Consts.ACTIVITYUPDATES);

        return pingService.sendAppropriateResonseToGarminApi(manualActivityUpdate);
    }

    @RequestMapping(value = "/moveiq", method = RequestMethod.POST)
    public ResponseEntity<String> handleMoveIqPingNotification(@RequestBody PingResponse moveIq) {
        log.info("MoveIQ endpoint ping notification");
        moveIq.setSummaryTitle(Consts.MOVEIQ);

        return pingService.sendAppropriateResonseToGarminApi(moveIq);
    }

    @RequestMapping(value = "/bodycompositions", method = RequestMethod.POST)
    public ResponseEntity<String> handleBodyCompositionsPingNotification(
            @RequestBody PingResponse bodyComp) {
        log.info("Body compositions endpoint ping notification");
        bodyComp.setSummaryTitle(Consts.BODYCOMPS);

        return pingService.sendAppropriateResonseToGarminApi(bodyComp);
    }

    @RequestMapping(value = "/dailies", method = RequestMethod.POST)
    public ResponseEntity<String> handleDailiesPingNotification(@RequestBody PingResponse dailies) {
        log.info("Dailies endpoint ping notification");
        dailies.setSummaryTitle(Consts.DAILIES);

        return pingService.sendAppropriateResonseToGarminApi(dailies);
    }

    @RequestMapping(value = "/epochs", method = RequestMethod.POST)
    public ResponseEntity<String> handleEpochPingNotification(@RequestBody PingResponse epochs) {
        log.info("Epochs endpoint ping notification");
        epochs.setSummaryTitle(Consts.EPOCHS);

        return pingService.sendAppropriateResonseToGarminApi(epochs);
    }

    @RequestMapping(value = "/pulseox", method = RequestMethod.POST)
    public ResponseEntity<String> handlePulseOxPingNotification(@RequestBody PingResponse pulseox) {
        log.info("Pulse ox endpoint ping notification");
        pulseox.setSummaryTitle(Consts.PULSEOX);

        return pingService.sendAppropriateResonseToGarminApi(pulseox);
    }

    @RequestMapping(value = "/respiration", method = RequestMethod.POST)
    public ResponseEntity<String> handleRespirationPingNotification(
            @RequestBody PingResponse respiration) {
        log.info("Respiration endpoint ping notification");
        respiration.setSummaryTitle(Consts.ALL_DAY_RESPIRATION);

        return pingService.sendAppropriateResonseToGarminApi(respiration);
    }

    @RequestMapping(value = "/sleep", method = RequestMethod.POST)
    public ResponseEntity<String> handleSleepPingNotification(@RequestBody PingResponse sleep) {
        log.info("Sleep endpoint ping notification");
        sleep.setSummaryTitle(Consts.SLEEPS);

        return pingService.sendAppropriateResonseToGarminApi(sleep);
    }

    @RequestMapping(value = "/stress", method = RequestMethod.POST)
    public ResponseEntity<String> handleStressPingNotification(@RequestBody PingResponse stress) {
        log.info("Stress endpoint ping notification");
        stress.setSummaryTitle(Consts.STRESS);

        return pingService.sendAppropriateResonseToGarminApi(stress);
    }

    @RequestMapping(value = "/thirdpartydailies", method = RequestMethod.POST)
    public ResponseEntity<String> handleThirdPartyDailiesPingNotification(
            @RequestBody PingResponse thirdPartyDailies) {
        log.info("Third-party dailies endpoint ping notification");
        thirdPartyDailies.setSummaryTitle(Consts.THIRD_PARTY_DAILIES);

        return pingService.sendAppropriateResonseToGarminApi(thirdPartyDailies);
    }

    @RequestMapping(value = "/usermetrics", method = RequestMethod.POST)
    public ResponseEntity<String> handleUserMetricsPingNotification(
            @RequestBody PingResponse userMetrics) {
        log.info("User metrics endpoint ping notification");
        userMetrics.setSummaryTitle(Consts.USERMETRICS);

        return pingService.sendAppropriateResonseToGarminApi(userMetrics);
    }

    @RequestMapping(value = "/menstrualcycletracking", method = RequestMethod.POST)
    public ResponseEntity<String> handleMenstrualCycleTrackingPingNotification(
            @RequestBody PingResponse menstrualCycle) {
        log.info("Menstrual cycle tracking endpoint ping notification");
        menstrualCycle.setSummaryTitle(Consts.MCT);

        return pingService.sendAppropriateResonseToGarminApi(menstrualCycle);
    }
}
