package com.garmin.partner.pingapi.Ping;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * The data inside the dictionary that is returned by the Ping service
 *
 * @author Greg Heiman
 */
public class PingNotification {

    @JsonProperty("userId")
    private String userId;

    @JsonProperty("userAccessToken")
    private String userAccessToken;

    @JsonProperty("uploadStartTimeInSeconds")
    private long uploadStartTimeInSeconds;

    @JsonProperty("uploadEndTimeInSeconds")
    private long uploadEndTimeInSeconds;

    @JsonProperty("callbackURL")
    private String callbackURL;

    public PingNotification() {}

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserAccessToken() {
        return userAccessToken;
    }

    public void setUserAccessToken(String userAccessToken) {
        this.userAccessToken = userAccessToken;
    }

    public long getUploadStartTimeInSeconds() {
        return uploadStartTimeInSeconds;
    }

    public void setUploadStartTimeInSeconds(long uploadStartTimeInSeconds) {
        this.uploadStartTimeInSeconds = uploadStartTimeInSeconds;
    }

    public long getUploadEndTimeInSeconds() {
        return uploadEndTimeInSeconds;
    }

    public void setUploadEndTimeInSeconds(long uploadEndTimeInSeconds) {
        this.uploadEndTimeInSeconds = uploadEndTimeInSeconds;
    }

    public String getCallbackURL() {
        return callbackURL;
    }

    public void setCallbackURL(String callbackURL) {
        this.callbackURL = callbackURL;
    }

    @Override
    public String toString() {
        return ("userId="
                + userId
                + "\n"
                + "userAccessToken="
                + userAccessToken
                + "\n"
                + "uploadStartTimeInSeconds="
                + uploadStartTimeInSeconds
                + "\n"
                + "uploadEndTimeInSeconds="
                + uploadEndTimeInSeconds
                + "\n"
                + "callbackURL="
                + callbackURL);
    }
}
