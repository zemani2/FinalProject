package com.garmin.partner.pingapi.Ping;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.garmin.partner.common.models.Partner;
import com.garmin.partner.common.models.SummaryData;
import com.garmin.partner.common.models.User;
import com.garmin.partner.common.models.UserAccessToken;
import com.garmin.partner.common.services.PartnerService;
import com.garmin.partner.common.services.SummaryDataService;
import com.garmin.partner.common.services.UserAccessTokenService;
import com.garmin.partner.common.services.UserService;
import com.garmin.partner.oauth.OAuthImpl;
import com.github.scribejava.core.model.Response;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * Service that manages the fetching of the data from the callback URLs in ping
 * responses.
 *
 * @author Greg Heiman
 */
@Service
public class PingService {
    private static final Logger log = LoggerFactory.getLogger(PingService.class);
    @Autowired
    private SummaryDataService summaryDataService;
    @Autowired
    private UserAccessTokenService userAccessTokenService;
    @Autowired
    private PartnerService partnerService;
    @Autowired
    private UserService userService;
    @Autowired
    private SessionFactory sessionFactory;
    @Autowired
    private OAuthImpl oAuthImpl;

    private SummaryData summary = new SummaryData();
    private UserAccessToken uat = new UserAccessToken();
    private User user = new User();
    private Partner partner = new Partner();

    private String summaryDomain;

    /**
     * Determine the correct HTTP response to send to the Garmin API and begin
     * callback process if response is not null. If you do not hit the callback URLs
     * asychronously you risk an HTTP timeout and data loss.
     *
     * @param a {@link PingResponse} from the Garmin API
     * @return a {@link ResponseEntity} with {@link HttpStatus} 200 if the response
     *         is not null and 400 otherwise
     */
    public ResponseEntity<String> sendAppropriateResonseToGarminApi(PingResponse pingResponse) {
        // Check to see if the PingResponse is not null
        if (pingResponse != null && pingResponse.getPingResponseBody() != null
                && pingResponse.getPingResponseBody().size() > 0) {
            // Hit the callback URL's asynchronously
            new Thread(() -> {
                if (manageCallbackProcess(pingResponse)) {
                    log.info("Callback process finished successfully.");
                } else {
                    log.error("There was an error in the callback process.");
                }
            }).start();

            // Per the docs send HTTP 200 after receiving ping response
            log.info("Sending acknowlegment - 200 for ping notication service");
            return new ResponseEntity<String>(HttpStatus.OK);
        } else {
            log.warn("Ping body recieved from Garmin API was null or empty.");
            log.warn("Sending acknowledgment - 204 for ping notification service");
            return new ResponseEntity<String>(HttpStatus.NO_CONTENT);
        }
    }

    /**
     * Manage the entire callback process.
     *
     * @param A {@link PingResponse} from the Garmin API
     * @return a {@link boolean} true if process was successful false otherwise
     */
    private boolean manageCallbackProcess(PingResponse pingResponses) {
        ArrayList<SummaryData> summaries = new ArrayList<SummaryData>();

        summaryDomain = pingResponses.getSummaryTitle();
        // Fill up a list with all of the summary data
        for (PingNotification pingNotification : pingResponses.getPingResponseBody()) {
            try {
                summaries = convertJsonToSummaryData(hitCallbackUrl(pingNotification));
            } catch (RuntimeException | ExecutionException | IOException e) {
                log.error("There was an error in converting the JSON to a summary data object.\n" + e.getMessage());
                e.printStackTrace();
            }
        }

        // Send all of the summary data in one transaction to the DB
        if (summaries.size() > 0) {
            return placeSummaryDataIntoDB(summaries);
        } else {
            log.warn("Summary list size is 0. Will not place empty data into DB.");
            return false;
        }
    }

    /**
     * Process the raw Json string from the Garmin API into a {@link SummaryData}
     * object.
     *
     * @param the json data from the Garmin API in {@link String} form
     * @throws IOException
     * @return an {@link ArrayList} of type {@link SummaryData}
     */
    private ArrayList<SummaryData> convertJsonToSummaryData(String json) throws IOException {
        ArrayList<SummaryData> summaryList = new ArrayList<SummaryData>();
        // Take the raw json and parse it out to a map
        try {
            for (HashMap<String, Object> map : parseJsonToMap(json)) {
                // Take the map and split it out into a SummaryData object
                summary = putCallbackDataIntoSummaryData(map);

                // Verify that the created SummaryData object is unique in the DB
                if (summaryDataService.verifyUniqueSummaryId(summary)) {
                    summaryList.add(summary);
                } else {
                    log.info("There is already an entry with summary_id: " + summary.getSummaryId()
                            + " will not add duplicates");
                }
            }
        } catch (JsonProcessingException e) {
            log.error(
                    "There was an error in converting the callback data into summary data objects.\n" + e.getMessage());
        }

        if (summaryList.size() != 0 && summaryList != null) {
            return summaryList;
        } else {
            throw new IOException("Summary list is empty. Cannot place empty list into DB.");
        }
    }

    /**
     * Open up a session and a transaction to place the summaries into the DB.
     *
     * @param summaries an {@link ArrayList} summaries that will be placed into the
     *                  DB.
     * @return {@link Boolean} true if the transaction was successful, false
     *         otherwise.
     */
    private boolean placeSummaryDataIntoDB(List<SummaryData> summaries) {
        Session session;
        // Try to obtain a session or open a session up
        try {
            session = sessionFactory.getCurrentSession();
        } catch (HibernateException e) {
            log.warn("No session found. Attempting to open a new session.");
            session = sessionFactory.openSession();
        }

        session.getTransaction().begin();

        // Add each of the summaries to the transaction
        long sessionLengthCounter = 0;
        for (SummaryData summary : summaries) {
            session.save(summary);
            sessionLengthCounter++;
        }

        boolean successful = false;
        try {
            // Commit the transaction
            session.getTransaction().commit();
            successful = true;
        } catch (HibernateException he) {
            if (session.getTransaction() != null) {
                // Rollback the transaction if there is an error
                session.getTransaction().rollback();
            }
            log.error("There was an error commiting the transaction to the DB.\n" + he.getMessage());
        } finally {
            session.close();
        }

        // Return whether the transaction was successful
        if (successful) {
            log.info("Transaction was commited successfully. Transaction contained " + sessionLengthCounter
                    + " entries.");
            return true;
        } else {
            log.warn("Could not verify if transaction was commited.");
            return false;
        }
    }

    /**
     * Prepare the models with the correct information nessacary for the OAuth
     * header.
     *
     * @param {@link String} userAccessToken: the uat that will be used to retrieve
     *               all of the information.
     */
    private void prepareOAuthHeader(String userAccessToken) {
        try {
            // Retreive the UAT secret from the DB
            uat.setUat(userAccessToken);
            uat = userAccessTokenService.findByUat(uat);

            // Obtain the user ID from the provided UAT
            user.setUserId(uat.getUserId());
            Long partnerId = userService.findByUserId(user).getPartnerId();

            // Obtain the partner ID from the user ID just obtained
            partner.setPartnerId(partnerId);
            partner = partnerService.findByPartnerId(partner);
        } catch (Exception e) {
            log.error("There was an error preparing the OAuth header for the callback URL.\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Prepare an OAuth header and attach that header to a request that is sent to
     * the callback URL.
     *
     * @param a {@link PingNotification} from the Garmin API.
     * @throws RuntimeException
     * @throws IOException
     * @throws ExecutionException
     * @return a {@link String} returned from the callback URL.
     */
    private String hitCallbackUrl(PingNotification pingBody) throws RuntimeException, IOException, ExecutionException {
        // Prepare all of the models for the OAuth header
        prepareOAuthHeader(pingBody.getUserAccessToken());

        // Create an OAuth access token to attach to the header of the response to send
        // to the callback URL
        oAuthImpl.createOAuthAccessToken(uat.getUat(), uat.getUatSecret());
        // Create the request to the Garmin API with the correct OAuth header attached
        oAuthImpl.createOAuthGetRequest(pingBody.getCallbackURL());

        // Create a service with the correct consumer key and secret
        oAuthImpl.setService(partner.getConsumerKey(), partner.getConsumerSecret());
        // Sign the request with with access token
        oAuthImpl.getService().signRequest(oAuthImpl.getAccessToken(), oAuthImpl.getRequest());

        // Send the request to the callback URL
        try {
            log.info("Sending response to callback url");
            final Future<Response> response = oAuthImpl.getService().executeAsync(oAuthImpl.getRequest());
            // Return the body of the request which houses the returned data from
            // Garmin
            while (!response.isDone()) {
                log.info("Fetching response from Garmin API...");
                Thread.sleep(300);
            }

            if (response.get().getBody().equals("[]") || response.get().getBody().isEmpty()
                    || response.get().getBody().length() == 0 || response.get().getBody().isBlank())
                throw new IOException("No body returned from callback URL");
            else {
                log.info("Fetched response from Garmin API.");
                return response.get().getBody();
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(ex);
        }
    }

    /**
     * Parse the JSON from the callback URL to a map of keys and values. This Map
     * will be used to store the information into a H2 database.
     *
     * @param json the raw json string returned from the callback url
     * @return an ArrayList of HashMaps that has all of the Json values mapped to
     *         the Json fields
     * @throws JsonProcessingException
     * @throws JsonMappingException
     */
    private ArrayList<HashMap<String, Object>> parseJsonToMap(String json)
            throws JsonMappingException, JsonProcessingException {
        ArrayList<HashMap<String, Object>> responseMap;
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
        responseMap = mapper.readValue(json, ArrayList.class);

        return responseMap;
    }

    /**
     * Creates a SummaryData object using the data provided from the callback URL.
     *
     * @param mapOfCallback {@link HashMap} of the JSON that was returned from the
     *                      callback
     * @param summaryTitle  {@link String} the title of the summary domain
     * @param userId        {@link String} the userId number for the DB
     * @return a {@link SummaryData} object with all the nesacary information
     *         attached
     */
    private SummaryData putCallbackDataIntoSummaryData(HashMap<String, Object> mapOfCallback) {
        SummaryData summaryData = new SummaryData();

        // Place the data into the SummaryData object to insert into the DB
        try {
            summaryData.setStartTime(Long.valueOf(mapOfCallback.get("startTimeInSeconds").toString()));
        } catch (NullPointerException npe) {
            log.warn("Could not set start time for summary " + mapOfCallback.get("summaryId").toString());
            summaryData.setStartTime(0L);
        }

        try {
            summaryData.setDuration(Long.valueOf(mapOfCallback.get("durationInSeconds").toString()));
        } catch (NullPointerException npe) {
            log.warn("Could not set duration for summary " + mapOfCallback.get("summaryId").toString());
            summaryData.setDuration(0L);
        }

        try {
            summaryData.setCalendarDate(
                    summaryData.formatDate(Long.valueOf(mapOfCallback.get("startTimeInSeconds").toString())));
        } catch (NullPointerException npe) {
            log.warn("Could not set calendar date for summary " + mapOfCallback.get("summaryId").toString());
        }

        try {
            summaryData.setSummaryDomain(summaryDomain);
        } catch (NullPointerException npe) {
            log.warn("Could not set summary domain for summary " + mapOfCallback.get("summaryId").toString());
        }

        // SummaryId cannot be null throw error
        try {
            summaryData.setSummaryId(mapOfCallback.get("summaryId").toString());
        } catch (NullPointerException npe) {
            log.error("Could not find summary Id for summary. Body of summary is:\n");
            mapOfCallback.forEach((key, value) -> log.info(key + " : " + value));
        }

        // UserId cannot be null throw error
        try {
            // Find the User ID from the token that was included in the Ping notification
            Long userId = userAccessTokenService.findByUat(uat).getUserId();
            summaryData.setUserId(userId);
        } catch (NullPointerException npe) {
            log.error("Could not find userId in summary. Will not place summary into DB without userId.");
        }

        // SummaryDataLob cannot be null
        try {
            summaryData.setSummaryDataLob(summaryData.setBlobBytes(mapOfCallback));
        } catch (SQLException se) {
            log.error("There was an error setting the lob data from the callback url. " + se.getMessage());
        } catch (NullPointerException npe) {
            log.error("Coulnd not set summary data lob. Will not place summary into DB without summary " + "data lob.");
        }

        return summaryData;
    }
}
