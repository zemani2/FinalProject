package com.garmin.partner.pingapi.Ping;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.garmin.partner.common.Consts;
import java.util.List;

/**
 * The library that is returned by the Ping Service
 *
 * @author Greg Heiman
 */
public class PingResponse {

    // The actual data within the library that is returned
    @JsonAlias({Consts.ACTIVITIES, Consts.DAILIES, Consts.THIRD_PARTY_DAILIES,
                Consts.EPOCHS, Consts.SLEEPS, Consts.BODYCOMPS, Consts.BLOODPRESSURES,
                Consts.ACTIVITYUPDATES, Consts.MOVEIQ, Consts.PULSEOX, Consts.MCT,
                Consts.ALL_DAY_RESPIRATION, Consts.STRESS, Consts.USERINFO,
                Consts.MCT, Consts.ACTIVITY_DETAILS, Consts.USERMETRICS})
    private List<PingNotification> pingResponseBody;

    // The title of the library. This is the same as the summary title
    private String summaryTitle;

    public List<PingNotification> getPingResponseBody() {
        return pingResponseBody;
    }

    public void setPingResponseBody(List<PingNotification> summaryType) {
        this.pingResponseBody = summaryType;
    }

    public String getSummaryTitle() {
        return summaryTitle;
    }

    public void setSummaryTitle(String summaryTitle) {
        this.summaryTitle = summaryTitle;
    }

    @Override
    public String toString() {
        return ("summaryTitle=" + summaryTitle + "\n" + pingResponseBody.toString());
    }
}
