# Sample Backfill Service
Sample implmentation for any domain that has backfill support.

## Requirements
* Java JDK 11
* Maven 3.8.1
* A valid evaluation app set up on [developerportal.garmin.com](https://developerportal.garmin.com)
with consumer key and consumer secret
* A test account created on [connecttest.garmin.com](https://connecttest.garmin.com)

## Installation
1. Clone the repository to your computer
2. Navigate to the parent repository
3. Run the following command:
    ```
    mvn clean package
    ```

## Using the Sample
This sample is a dependency of both the ping and pull sample implementations.
In order to use this sample simply start one of those implementation as you would normally
and access one of the backfill endpoints.

**Before issuing a backfill request you must have a valid consumer and user set up in your 
local DB.**

## Query Parameters for Backfill Endpoints
Each backfill endpoint requires three query parameters:
    ```
    uat (The user access token from which to retrieve the backfill data for)
    ```
    ```
    startTime (The start time of the backfill)
    ```
    ```
    endTime (The end time of the backfill)
    ```
