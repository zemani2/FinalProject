package com.garmin.partner.backfillapi.controller;

import com.garmin.partner.common.Consts;
import com.garmin.partner.backfillapi.models.BackfillObject;
import com.garmin.partner.backfillapi.BackfillService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controls the endpoints for the Backfill service.
 *
 * @author Greg Heiman
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/backfill")
public class BackfillApiController {
    private static final Logger log = LoggerFactory.getLogger(BackfillApiController.class);

    @Autowired
    private BackfillService backfillService;
    private BackfillObject backfillObject = new BackfillObject();

    /** Test endpoint for the backfill service. Simply returns a message. */
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public String handleTestEndpoint() {
        return "Hello. This test endpoint is working";
    }

    @RequestMapping(value = "/activities", method = RequestMethod.GET)
    public ResponseEntity<String> handleActivityBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("Activities endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.ACTIVITIES);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/moveiq", method = RequestMethod.GET)
    public ResponseEntity<String> handleMoveIqBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("MoveIQ endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.MOVEIQ);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/bodycompositions", method = RequestMethod.GET)
    public ResponseEntity<String> handleBodyCompositionsBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("Body compositions endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.BODYCOMPS);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/dailies", method = RequestMethod.GET)
    public ResponseEntity<String> handleDailiesBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("Dailies endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.DAILIES);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/epochs", method = RequestMethod.GET)
    public ResponseEntity<String> handleEpochBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("Epochs endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.EPOCHS);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/sleep", method = RequestMethod.GET)
    public ResponseEntity<String> handleSleepBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("Sleep endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.SLEEPS);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/stress", method = RequestMethod.GET)
    public ResponseEntity<String> handleStressBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("Stress endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.STRESS);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/usermetrics", method = RequestMethod.GET)
    public ResponseEntity<String> handleUserMetricsBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("User metrics endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.USERMETRICS);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }

    @RequestMapping(value = "/menstrualcycletracking", method = RequestMethod.GET)
    public ResponseEntity<String> handleMenstrualCycleTrackingBackfillNotification(
            @RequestParam String uat,
            @RequestParam Long startTime,
            @RequestParam Long endTime) {
        log.info("Menstrual cycle tracking endpoint backfill notification");
        backfillObject.setSummaryTitle(Consts.MCT);
        backfillObject.setUserAccessToken(uat);
        backfillObject.setSummaryStartTime(startTime);
        backfillObject.setSummaryEndTime(endTime);

        return backfillService.handleBackfillRequest(backfillObject);
    }
}
