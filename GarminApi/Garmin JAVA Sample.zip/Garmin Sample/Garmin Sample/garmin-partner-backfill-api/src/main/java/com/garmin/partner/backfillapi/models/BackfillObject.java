package com.garmin.partner.backfillapi.models;

public class BackfillObject {
    private String summaryTitle;
    private String userAccessToken;
    private Long summaryStartTime;
    private Long summaryEndTime;


    public Long getSummaryEndTime() {
        return summaryEndTime;
    }

    public void setSummaryEndTime(Long summaryEndTime) {
        this.summaryEndTime = summaryEndTime;
    }

    public Long getSummaryStartTime() {
        return summaryStartTime;
    }

    public void setSummaryStartTime(Long summaryStartTime) {
        this.summaryStartTime = summaryStartTime;
    }

    public String getUserAccessToken() {
        return userAccessToken;
    }

    public void setUserAccessToken(String userAccessToken) {
        this.userAccessToken = userAccessToken;
    }

    public String getSummaryTitle() {
        return summaryTitle;
    }

    public void setSummaryTitle(String summaryTitle) {
        this.summaryTitle = summaryTitle;
    }

    @Override
    public String toString() {
        return "BackfillObject [summaryTitle=" + summaryTitle + " userAccessToken=" + userAccessToken +
            " summaryStartTime=" + summaryStartTime + " summaryEndTime=" + summaryEndTime + "]";
    }
}
