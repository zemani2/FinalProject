package com.garmin.partner.backfillapi;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ExecutionException;

import com.garmin.partner.backfillapi.models.BackfillObject;
import com.garmin.partner.common.Consts;
import com.garmin.partner.common.models.Partner;
import com.garmin.partner.common.models.User;
import com.garmin.partner.common.models.UserAccessToken;
import com.garmin.partner.common.services.PartnerService;
import com.garmin.partner.common.services.UserAccessTokenService;
import com.garmin.partner.common.services.UserService;
import com.garmin.partner.oauth.OAuthImpl;
import com.github.scribejava.core.model.OAuthRequest;
import com.github.scribejava.core.model.Response;

import org.apache.http.client.utils.URIBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * Service that manages the sending of backfill requests to the Garmin API.
 * 
 * @author Greg Heiman
 */
@Service
public class BackfillService {
    private static final Logger log = LoggerFactory.getLogger(BackfillService.class);

    private UserAccessToken uat = new UserAccessToken();
    private User user = new User();
    private Partner partner = new Partner();

    @Autowired
    private UserAccessTokenService userAccessTokenService;
    @Autowired
    private UserService userService;
    @Autowired
    private PartnerService partnerService;
    @Autowired
    private OAuthImpl oAuthImpl;

    /** 
     * Handle the entirety of the backfill request process.
     *
     * @param backfillRequestObject a {@link BackfillObject} from the controller endpoint.
     * @return a {@link ResponseEntity} with status 200 if request was sent successfully 400 otherwise
     */    
    public ResponseEntity<String> handleBackfillRequest(BackfillObject backfillRequestObject) {
        prepareModelsForOAuthHeader(backfillRequestObject.getUserAccessToken());
        boolean success = false;

        try {
            URI fullBackfillURI = formatBackfillUrl(determineSummaryDomainForBackfillRequest(backfillRequestObject.getSummaryTitle()),
                              backfillRequestObject);
            buildOAuthHeader(fullBackfillURI.toString());
            success = sendBackfillRequest(oAuthImpl.getRequest());
        } catch (IOException ioe) {
            log.error("There was an error in sending the backfill request to Garmin.\n"
                      + ioe.getMessage());
        } catch (URISyntaxException urse) {
            log.error("There was an error in appending the parameters to the backfill request.\n"
                      + urse.getMessage());
        } catch (ExecutionException exep) {
            log.error("There was an error in executing the backfill request.\n" + 
                      exep.getMessage());
        } 

        if (success) {
            return new ResponseEntity<String>("Backfill request submitted successfully.", HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("There was a problem submitting the backfill request.",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Prepare the common models for the OAuth process by working back to the partner info from
     * the provided user access token.
     *
     * @param userAccessToken the provided query parameter for the uat field.
     */    
    private void prepareModelsForOAuthHeader(String userAccessToken) {
        uat.setUat(userAccessToken);
        uat = userAccessTokenService.findByUat(uat);

        user.setUserId(uat.getUserId());
        user = userService.findByUserId(user);
        
        partner.setPartnerId(user.getPartnerId());
        partner = partnerService.findByPartnerId(partner);
    }
    
    /**
     * Use the summaryTitle filed in the {@link BackfillObject} to determine which URL to send the
     * backfill request to.
     *
     * @param summaryTitle a {@link String} that is the title of the summary domain for which to submit
     * the backfill request for.
     * @return a string url for the specified summary domain.    
     */    
    private String determineSummaryDomainForBackfillRequest(String summaryTitle) throws IOException {
        switch (summaryTitle) {
            case Consts.ACTIVITIES:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/activities";
            case Consts.MOVEIQ:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/moveiq";
            case Consts.BODYCOMPS:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/bodyComps";
            case Consts.DAILIES:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/dailies";
            case Consts.EPOCHS:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/epochs";
            case Consts.SLEEPS:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/sleeps";
            case Consts.STRESS:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/stressDetails";
            case Consts.USERMETRICS:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/userMetrics";
            case Consts.MCT:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/mct";
            case Consts.PULSEOX:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/pulseOx";
           case Consts.ALL_DAY_RESPIRATION:
                return "https://healthapitest.garmin.com/wellness-api/rest/backfill/respiration";
            default:
                throw new IOException("Couldn't match the summary domain: " + summaryTitle + " to a valid "
                                      + "backfill domain.");
        }
    }
    
    /**
     * Add the summaryStartTimeInSeconds and summaryEndTimeInSeconds query parameters to the 
     * partial backfill request url that was created based on the summary title attached to the 
     *    {@link BackfillObject}
     * 
     * @param baseBackfillUrl a {@link String} consisting of the base backfill URL without query parameters
     */    
    private URI formatBackfillUrl(String baseBackfillUrl, BackfillObject backfillObject) throws URISyntaxException {
        URIBuilder uriBuilder = new URIBuilder(baseBackfillUrl);
        uriBuilder.addParameter("summaryStartTimeInSeconds", backfillObject.getSummaryStartTime().toString());
        uriBuilder.addParameter("summaryEndTimeInSeconds", backfillObject.getSummaryEndTime().toString());

        return uriBuilder.build();
    }
    
    /**
     * Build the OAuth header that will be attached to the backfill request.
     * 
     * @param fullBackFillUrl a {@link String} that is the full url with attached summaryStartTimeInSeconds
     * and summaryEndTimeInSeconds query parameters.
     */    
    private void buildOAuthHeader(String fullBackfillUrl) {
        oAuthImpl.createOAuthAccessToken(uat.getUat(), uat.getUatSecret());
    
        oAuthImpl.createOAuthGetRequest(fullBackfillUrl);
    
        oAuthImpl.setService(partner.getConsumerKey(), partner.getConsumerSecret());
    }
    
    /**
     * Send the backfill request to Garmin and ensure that an expected response came back.
     *
     * @throws IOException any IOException
     * @throws ExecutionException any ExecutionException
     */
    private boolean sendBackfillRequest(OAuthRequest backfillRequest) throws IOException, ExecutionException {
        oAuthImpl.getService().signRequest(oAuthImpl.getAccessToken(), backfillRequest);
        
        try {
            log.info("Sending backfill request to Garmin");
            final Response response = oAuthImpl.getService().execute(backfillRequest);

            if (response.getBody().equals("[]") || response.getBody().isEmpty()
                || response.getBody().length() == 0 || response.getBody().isBlank()) {
                log.info("Recieved expected blank response from Garmin.");

                if (response.getCode() == 202) {
                    log.info("Recieved expected HTTP 202 response from Garmin.");
                    return true;
                } else {
                    throw new IOException("Recieved unexpected HTTP " + response.getCode() + " response from Garmin");
                }
            } else {
                throw new IOException("Recieved non-blank response from Garmin.\n"
                                      + "Body:\n" + response.getBody());
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(ex);
        }
    }
}
