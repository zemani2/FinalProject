# Garmin Partner Model
Generates client model objects for each of our apis, uses the swagger yaml/json 
documentation and swagger's client code generator. Can output client models for 
a variety of supported languages see https://swagger.io/tools/swagger-codegen/.

## How to run the project
This project uses the [Swagger Codegen Maven Plugin](https://github.com/swagger-api/swagger-codegen/tree/3.0.0/modules/swagger-codegen-maven-plugin)
in order to generate the models. This plugin is configured inside to the **pom.xml** file.
The default is set up for Java however it can be easily changed in the configuration.

In order to generate the models you simply need to run:
```
mvn generate-sources
```
The sources will be placed inside of the **target/generated-sources** folder upon
completion.

### What if I want to use a language besides Java?
Simply go into the pom.xml file at the root of the **garmin-partner-model** folder
and change the **<language>** tag.
```
<language>python<language>
```

### The Maven verify phase failed.
This is a [known issue](https://github.com/swagger-api/swagger-codegen/issues/9038) 
on the Swagger codegen side when generating Java or Spring files. To fix this 
issue simply include the following tag in the pom.xml.
```
<environmentVariables>
    <supportingFiles>ApiClient.java,Authentication.java,OAuth.java,ApiKeyAuth.java,HttpBasicAuth.java,RFC3339DateFormat.java</supportingFiles>
</environmentVariables>
```





