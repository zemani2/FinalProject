# ClientSummarizedMenstrualCycle

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currentPhase** | **Integer** |  |  [optional]
**currentPhaseType** | **String** |  |  [optional]
**cycleLength** | **Integer** |  |  [optional]
**dayInCycle** | **Integer** |  |  [optional]
**daysUntilNextPhase** | **Integer** |  |  [optional]
**fertileWindowStart** | **Integer** |  |  [optional]
**hasSpecifiedCycleLength** | **Boolean** |  |  [optional]
**hasSpecifiedPeriodLength** | **Boolean** |  |  [optional]
**isPredictedCycle** | **Boolean** |  |  [optional]
**lastUpdatedTimeInSeconds** | **Integer** |  |  [optional]
**lengthOfCurrentPhase** | **Integer** |  |  [optional]
**lengthOfFertileWindow** | **Integer** |  |  [optional]
**periodLength** | **Integer** |  |  [optional]
**periodStartDate** | **String** |  |  [optional]
**predictedCycleLength** | **Integer** |  |  [optional]
**pregnancySnapshot** | [**ClientPregnancySnapshot**](ClientPregnancySnapshot.md) |  |  [optional]
**summaryId** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
