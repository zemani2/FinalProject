# ClientUserInfo

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gender** | **String** |  |  [optional]
**heightInCentimeters** | **Integer** |  |  [optional]
**modifiedTimeInSeconds** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**timeZone** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**weightInGrams** | **Integer** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
