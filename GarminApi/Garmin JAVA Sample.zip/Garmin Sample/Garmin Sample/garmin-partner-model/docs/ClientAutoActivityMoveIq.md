# ClientAutoActivityMoveIq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activitySubType** | **String** |  |  [optional]
**activityType** | **String** |  |  [optional]
**calendarDate** | **String** |  |  [optional]
**deviceName** | **String** |  |  [optional]
**durationInSeconds** | **Integer** |  |  [optional]
**offsetInSeconds** | **Integer** |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
