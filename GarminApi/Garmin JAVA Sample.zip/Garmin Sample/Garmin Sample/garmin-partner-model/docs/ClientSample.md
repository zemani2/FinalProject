# ClientSample

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**acceleration** | [**ClientAcceleration**](ClientAcceleration.md) |  |  [optional]
**heartBeatIntervalsInMilliseconds** | **List&lt;Integer&gt;** |  |  [optional]
**measurementTimeInSeconds** | **Integer** |  |  [optional]
