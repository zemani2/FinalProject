# ClientRespiration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**durationInSeconds** | **Integer** |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
**startTimeOffsetInSeconds** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**timeOffsetEpochToBreaths** | **Map&lt;String, Float&gt;** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
