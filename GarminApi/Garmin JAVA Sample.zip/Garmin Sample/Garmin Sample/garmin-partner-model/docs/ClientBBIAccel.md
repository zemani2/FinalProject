# ClientBBIAccel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**samples** | [**List&lt;ClientSample&gt;**](ClientSample.md) |  |  [optional]
**summaryId** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
