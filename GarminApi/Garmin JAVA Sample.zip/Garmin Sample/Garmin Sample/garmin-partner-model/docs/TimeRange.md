# TimeRange

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**endTimeInSeconds** | **Integer** |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
