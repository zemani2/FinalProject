# ClientEpoch

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activeKilocalories** | **Integer** |  |  [optional]
**activeTimeInSeconds** | **Integer** |  |  [optional]
**activityType** | **String** |  |  [optional]
**distanceInMeters** | **Float** |  |  [optional]
**durationInSeconds** | **Integer** |  |  [optional]
**intensity** | **String** |  |  [optional]
**maxMotionIntensity** | **Double** |  |  [optional]
**meanMotionIntensity** | **Double** |  |  [optional]
**met** | **Float** |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
**startTimeOffsetInSeconds** | **Integer** |  |  [optional]
**steps** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**timeOffsetBodyBatterySamples** | **Map&lt;String, Integer&gt;** |  |  [optional]
**timeOffsetHeartRateSamples** | **Map&lt;String, Integer&gt;** |  |  [optional]
**timeOffsetStressLevelSamples** | **Map&lt;String, Integer&gt;** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
