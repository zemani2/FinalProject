# ClientStress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**averageStressLevel** | **Integer** |  |  [optional]
**calendarDate** | **String** |  |  [optional]
**durationInSeconds** | **Integer** |  |  [optional]
**maxStressLevel** | **Integer** |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
**startTimeOffsetInSeconds** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**timeOffsetBodyBatteryValues** | **Map&lt;String, Integer&gt;** |  |  [optional]
**timeOffsetStressLevelValues** | **Map&lt;String, Integer&gt;** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
