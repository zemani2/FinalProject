# ClientLap

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**startTimeInSeconds** | **Integer** |  |  [optional]
