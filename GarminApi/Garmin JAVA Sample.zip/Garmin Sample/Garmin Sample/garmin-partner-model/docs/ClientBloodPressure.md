# ClientBloodPressure

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**diastolic** | **Integer** |  |  [optional]
**heartRateInBeatsPerMinute** | **Integer** |  |  [optional]
**meanArterialPressure** | **Integer** |  |  [optional]
**measurementTimeInSeconds** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**systolic** | **Integer** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
