# ClientDailySpo2Acclimation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calendarDate** | **String** |  |  [optional]
**durationInSeconds** | **Integer** |  |  [optional]
**onDemand** | **Boolean** |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
**startTimeOffsetInSeconds** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**timeOffsetSpo2Values** | **Map&lt;String, Integer&gt;** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
