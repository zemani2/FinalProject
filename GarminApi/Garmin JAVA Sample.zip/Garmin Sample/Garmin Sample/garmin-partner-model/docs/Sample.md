# Sample

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**airTemperatureCelcius** | **Double** |  |  [optional]
**bikeCadenceInRPM** | **Double** |  |  [optional]
**clockDurationInSeconds** | **Integer** |  |  [optional]
**elevationInMeters** | **Double** |  |  [optional]
**heartRate** | **Integer** |  |  [optional]
**latitudeInDegree** | **Double** |  |  [optional]
**longitudeInDegree** | **Double** |  |  [optional]
**movingDurationInSeconds** | **Integer** |  |  [optional]
**powerInWatts** | **Double** |  |  [optional]
**speedMetersPerSecond** | **Double** |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
**stepsPerMinute** | **Double** |  |  [optional]
**swimCadenceInStrokesPerMinute** | **Double** |  |  [optional]
**timerDurationInSeconds** | **Integer** |  |  [optional]
**totalDistanceInMeters** | **Double** |  |  [optional]
