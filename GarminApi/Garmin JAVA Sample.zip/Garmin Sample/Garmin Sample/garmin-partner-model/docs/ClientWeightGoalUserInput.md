# ClientWeightGoalUserInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**heightInCentimeters** | **Integer** |  |  [optional]
**weightInGrams** | **Integer** |  |  [optional]
