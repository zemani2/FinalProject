# ClientActivityDetail

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**activityId** | **Long** |  |  [optional]
**laps** | [**List&lt;ClientLap&gt;**](ClientLap.md) |  |  [optional]
**samples** | [**List&lt;Sample&gt;**](Sample.md) |  |  [optional]
**summary** | [**ClientActivity**](ClientActivity.md) |  |  [optional]
**summaryId** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
