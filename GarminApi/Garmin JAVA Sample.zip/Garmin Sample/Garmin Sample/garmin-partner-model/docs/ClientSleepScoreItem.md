# ClientSleepScoreItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**qualifierKey** | **String** |  |  [optional]
**value** | **Integer** |  |  [optional]
