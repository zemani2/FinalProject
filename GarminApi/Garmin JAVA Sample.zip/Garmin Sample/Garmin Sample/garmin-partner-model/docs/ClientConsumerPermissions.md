# ClientConsumerPermissions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**changeTimeInSeconds** | **Integer** |  |  [optional]
**permissions** | **List&lt;String&gt;** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
