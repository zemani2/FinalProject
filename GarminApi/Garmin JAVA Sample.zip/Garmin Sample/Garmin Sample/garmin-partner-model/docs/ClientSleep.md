# ClientSleep

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**awakeDurationInSeconds** | **Integer** |  |  [optional]
**calendarDate** | **String** |  |  [optional]
**deepSleepDurationInSeconds** | **Integer** |  |  [optional]
**durationInSeconds** | **Integer** |  |  [optional]
**lightSleepDurationInSeconds** | **Integer** |  |  [optional]
**overallSleepScore** | [**ClientSleepScoreItem**](ClientSleepScoreItem.md) |  |  [optional]
**remSleepInSeconds** | **Integer** |  |  [optional]
**sleepLevelsMap** | [**Map&lt;String, List&lt;TimeRange&gt;&gt;**](List.md) |  |  [optional]
**sleepScores** | [**Map&lt;String, ClientSleepScoreItem&gt;**](ClientSleepScoreItem.md) |  |  [optional]
**startTimeInSeconds** | **Integer** |  |  [optional]
**startTimeOffsetInSeconds** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**timeOffsetSleepRespiration** | **Map&lt;String, Float&gt;** |  |  [optional]
**timeOffsetSleepSpo2** | **Map&lt;String, Integer&gt;** |  |  [optional]
**unmeasurableSleepInSeconds** | **Integer** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**validation** | **String** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
