# ClientPregnancySnapshot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bloodGlucoseList** | [**List&lt;ClientBloodGlucose&gt;**](ClientBloodGlucose.md) |  |  [optional]
**deliveryDate** | **String** |  |  [optional]
**dueDate** | **String** |  |  [optional]
**endDate** | **String** |  |  [optional]
**hasExperiencedLoss** | **Boolean** |  |  [optional]
**lossReportTimestampInSeconds** | **Integer** |  |  [optional]
**numOfBabies** | **String** |  |  [optional]
**originalDueDate** | **String** |  |  [optional]
**pregnancyCycleStartDate** | **String** |  |  [optional]
**stopTracking** | **Boolean** |  |  [optional]
**stopTrackingTimestampInSeconds** | **Integer** |  |  [optional]
**title** | **String** |  |  [optional]
**weightGoalUserInput** | [**ClientWeightGoalUserInput**](ClientWeightGoalUserInput.md) |  |  [optional]
