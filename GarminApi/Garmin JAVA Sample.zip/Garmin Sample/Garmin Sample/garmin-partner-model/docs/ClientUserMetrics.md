# ClientUserMetrics

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**calendarDate** | **String** |  |  [optional]
**fitnessAge** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**vo2Max** | **Double** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
