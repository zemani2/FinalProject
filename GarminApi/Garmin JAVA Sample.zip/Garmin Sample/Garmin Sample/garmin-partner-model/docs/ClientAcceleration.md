# ClientAcceleration

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**frequencyInHz** | **Integer** |  |  [optional]
**pitchSamplesInDegree** | **List&lt;Float&gt;** |  |  [optional]
**powerSamplesInMilliG** | **List&lt;Integer&gt;** |  |  [optional]
**rollSamplesInDegree** | **List&lt;Float&gt;** |  |  [optional]
**xSamplesInMilliG** | **List&lt;Integer&gt;** |  |  [optional]
**ySamplesInMilliG** | **List&lt;Integer&gt;** |  |  [optional]
**zSamplesInMilliG** | **List&lt;Integer&gt;** |  |  [optional]
