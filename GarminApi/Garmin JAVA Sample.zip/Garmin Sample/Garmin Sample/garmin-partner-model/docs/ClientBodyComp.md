# ClientBodyComp

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bodyFatInPercent** | **Float** |  |  [optional]
**bodyMassIndex** | **Float** |  |  [optional]
**bodyWaterInPercent** | **Float** |  |  [optional]
**boneMassInGrams** | **Integer** |  |  [optional]
**measurementTimeInSeconds** | **Integer** |  |  [optional]
**measurementTimeOffsetInSeconds** | **Integer** |  |  [optional]
**muscleMassInGrams** | **Integer** |  |  [optional]
**summaryId** | **String** |  |  [optional]
**userAccessToken** | **String** |  |  [optional]
**userId** | **String** |  |  [optional]
**weightInGrams** | **Integer** |  |  [optional]
**wellnessSummaryId** | **String** |  |  [optional]
