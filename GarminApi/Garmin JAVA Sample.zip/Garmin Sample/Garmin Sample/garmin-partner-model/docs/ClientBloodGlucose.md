# ClientBloodGlucose

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**logType** | **String** |  |  [optional]
**reportTimestampInSeconds** | **Integer** |  |  [optional]
**valueInMilligramsPerDeciliter** | **Double** |  |  [optional]
