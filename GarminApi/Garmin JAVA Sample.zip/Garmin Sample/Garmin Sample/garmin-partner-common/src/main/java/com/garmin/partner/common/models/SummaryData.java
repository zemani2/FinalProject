package com.garmin.partner.common.models;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.garmin.partner.common.Consts;
import com.garmin.partner.model.ClientActivity;
import com.garmin.partner.model.ClientActivityDetail;
import com.garmin.partner.model.ClientAutoActivityMoveIq;
import com.garmin.partner.model.ClientBodyComp;
import com.garmin.partner.model.ClientDaily;
import com.garmin.partner.model.ClientDailySpo2Acclimation;
import com.garmin.partner.model.ClientEpoch;
import com.garmin.partner.model.ClientRespiration;
import com.garmin.partner.model.ClientSleep;
import com.garmin.partner.model.ClientStress;
import com.garmin.partner.model.ClientSummarizedMenstrualCycle;
import com.garmin.partner.model.ClientUserMetrics;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Database object that represents an entry in the summary_data table.
 *
 * @author Greg Heiman
 */
@Entity
@Table(name = "\"summary_data\"")
public class SummaryData {
    private static final Logger log = LoggerFactory.getLogger(SummaryData.class);

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"id\"")
    private Long id;

    @Column(name = "\"start_time\"")
    private Long startTime;

    @Column(name = "\"duration\"")
    private Long duration;

    @Column(name = "\"summary_data_lob\"")
    private Blob summaryDataLob;

    @Column(name = "\"calendar_date\"")
    private String calendarDate;

    @Column(name = "\"summary_domain\"")
    private String summaryDomain;

    @Column(name = "\"summary_id\"")
    private String summaryId;

    @Column(name = "\"user_id\"")
    private Long userId;

    public SummaryData() {}

    public SummaryData(
            Long startTime,
            Blob summaryDataLob,
            String calendarDate,
            String summaryDomain,
            String summaryId,
            Long userId) {
        this.startTime = startTime;
        this.summaryDataLob = summaryDataLob;
        this.calendarDate = calendarDate;
        this.summaryDomain = summaryDomain;
        this.summaryId = summaryId;
        this.userId = userId;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getCalendarDate() {
        return calendarDate;
    }

    public void setCalendarDate(String calendarDate) {
        this.calendarDate = calendarDate;
    }

    public String getSummaryDomain() {
        return summaryDomain;
    }

    public void setSummaryDomain(String summaryDomain) {
        this.summaryDomain = summaryDomain;
    }

    public String getSummaryId() {
        return summaryId;
    }

    public void setSummaryId(String summaryId) {
        this.summaryId = summaryId;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public Blob getSummaryDataLob() {
        return summaryDataLob;
    }

    public void setSummaryDataLob(SerialBlob blob) {
        summaryDataLob = blob;
    }

    /**
     * Sets the summary data lob for the SummaryData object. Will first determine the appropriate
     * client model and then will serialize that model into a blob.
     *
     * @param clientModelMap a map representing the json returned from Garmin
     */
    public SerialBlob setBlobBytes(HashMap<String, Object> clientModelMap)
            throws SerialException, SQLException {
        return new SerialBlob(
                convertJsonAsClientModelToBytes(determineClientModelFromDomain(clientModelMap)));
    }

    /**
     * Converts the client model object into an array of bytes that will be placed into the DB.
     *
     * @param object and object representing the determined client model
     * @return the byte array from the client model serialization
     */
    private byte[] convertJsonAsClientModelToBytes(Object object) {
        log.info("Converting to byte array");

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (ObjectOutputStream out = new ObjectOutputStream(bos)) {
            out.writeObject(object);
        } catch (IOException e) {
            log.error("There was an error converting client model to byte array." + e.getMessage());
        }

        return bos.toByteArray();
    }

    @Override
    public String toString() {
        return ("SummaryData:\n"
                + "startTime: "
                + startTime
                + "\n"
                + "duration: "
                + duration
                + "\n"
                + "calendarDate: "
                + calendarDate
                + "\n"
                + "summaryDomain: "
                + summaryDomain
                + "\n"
                + "summaryId: "
                + summaryId
                + "\n"
                + "userId: "
                + userId);
    }

    /**
     * Determine the client model to use (the files that were generated by Swagger). This client
     * model will be serialized and then placed into the DB where it can then be de-serialized
     * whenever the data needs to be retrieved
     *
     * @param json a hashmap that represents the Json returned from Garmin
     * @return an object that represents the client model that will be serialized
     */
    public Object determineClientModelFromDomain(HashMap<String, Object> json) {
        Object clientModel = null;
        log.info("At the client model determination");

        if (summaryDomain == Consts.ACTIVITIES) {
            clientModel = new ObjectMapper().convertValue(json, ClientActivity.class);
            log.info("Determined client model to be activity.");
            return clientModel;
        } else if (summaryDomain == Consts.ACTIVITYUPDATES) {
            // Manually updated activity uses ClientActivity
            clientModel = new ObjectMapper().convertValue(json, ClientActivity.class);
            log.info("Determined client model to be manually updated activity.");
            return clientModel;
        } else if (summaryDomain == Consts.EPOCHS) {
            log.info("Determined client model to be epochs.");
            clientModel = new ObjectMapper().convertValue(json, ClientEpoch.class);
            return clientModel;
        } else if (summaryDomain == Consts.ACTIVITY_DETAILS) {
            log.info("Determined client model to be activity details.");
            clientModel = new ObjectMapper().convertValue(json, ClientActivityDetail.class);
            return clientModel;
        } else if (summaryDomain == Consts.DAILIES) {
            log.info("Determined client model to be dailies.");
            clientModel = new ObjectMapper().convertValue(json, ClientDaily.class);
            return clientModel;
        } else if (summaryDomain == Consts.THIRD_PARTY_DAILIES) {
            log.info("Determined client model to be third-party dailies.");
            // Third party dailies just use the ClientDaily model
            clientModel = new ObjectMapper().convertValue(json, ClientDaily.class);
            return clientModel;
        } else if (summaryDomain == Consts.MOVEIQ) {
            log.info("Determined client model to be move iq.");
            clientModel = new ObjectMapper().convertValue(json, ClientAutoActivityMoveIq.class);
            return clientModel;
        } else if (summaryDomain == Consts.BODYCOMPS) {
            log.info("Determined client model to be body composition.");
            clientModel = new ObjectMapper().convertValue(json, ClientBodyComp.class);
            return clientModel;
        } else if (summaryDomain == Consts.ALL_DAY_RESPIRATION) {
            log.info("Determined client model to be respiration.");
            clientModel = new ObjectMapper().convertValue(json, ClientRespiration.class);
            return clientModel;
        } else if (summaryDomain == Consts.SLEEPS) {
            log.info("Determined client model to be sleep.");
            clientModel = new ObjectMapper().convertValue(json, ClientSleep.class);
            return clientModel;
        } else if (summaryDomain == Consts.STRESS) {
            log.info("Determined client model to be stress.");
            clientModel = new ObjectMapper().convertValue(json, ClientStress.class);
            return clientModel;
        } else if (summaryDomain == Consts.USERMETRICS) {
            log.info("Determined client model to be user metrics.");
            clientModel = new ObjectMapper().convertValue(json, ClientUserMetrics.class);
            return clientModel;
        } else if (summaryDomain == Consts.MCT) {
            log.info("Determined client model to be user menstrual cycle.");
            clientModel = new ObjectMapper().convertValue(json, ClientSummarizedMenstrualCycle.class);
            return clientModel;
        } else if (summaryDomain == Consts.PULSEOX) {
            log.info("Determined client model to be pulse ox.");
            // Pulse ox uses ClientDailySpo2Acclimation
            clientModel = new ObjectMapper().convertValue(json, ClientDailySpo2Acclimation.class);
            return clientModel;
        }

        return clientModel;
    }

    /**
     * Format the date for the calendar date field in the summary_data table
     *
     * @param seconds UTC seconds from the startTimeInSeconds field
     */
    public String formatDate(long seconds) {
        LocalDateTime dateTime = LocalDateTime.ofEpochSecond(seconds, 0, ZoneOffset.UTC);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE,MMMM d,yyyy h:mm,a");
        return dateTime.format(formatter);
    }
}
