package com.garmin.partner.common.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Class that represents a row in the user_access_token table in the H2 DB.
 *
 * @author Greg Heiman
 */
@Entity
@Table(name = "\"user_access_token\"")
public class UserAccessToken {
    @Column(name = "\"uat\"")
    private String uat;

    @Column(name = "\"uat_secret\"")
    private String uatSecret;

    @Column(name = "\"user_id\"")
    @Id
    private long userId;

    public UserAccessToken() {}

    public UserAccessToken(String uat, String uatSecret) {
        this.uat = uat;
        this.uatSecret = uatSecret;
    }

    public String getUat() {
        return uat;
    }

    public void setUat(String uat) {
        this.uat = uat;
    }

    public String getUatSecret() {
        return uatSecret;
    }

    public void setUatSecret(String uatSecret) {
        this.uatSecret = uatSecret;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return ("UserAccessToken:\n"
                + "uat: "
                + uat
                + "\n"
                + "uatSecret: "
                + uatSecret
                + "\n"
                + "userId: "
                + userId);
    }
}
