package com.garmin.partner.common.services;

import com.garmin.partner.common.models.SummaryData;
import com.garmin.partner.common.repositories.SummaryDataRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SummaryDataService {
    @Autowired private SummaryDataRepository summaryDataRepository;

    public List<SummaryData> listSummaryData() {
        return summaryDataRepository.findAll();
    }

    public boolean verifyUniqueSummaryId(SummaryData summary) {
        return summaryDataRepository.verifyUniqueSummaryId(summary.getSummaryId());
    }

    public void saveSummaryData(SummaryData summary) {
        summaryDataRepository.save(summary);
    }
}
