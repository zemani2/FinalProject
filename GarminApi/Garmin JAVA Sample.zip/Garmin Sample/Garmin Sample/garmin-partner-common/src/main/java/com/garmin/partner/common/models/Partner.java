package com.garmin.partner.common.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Class that holds information about a partner entry in the partner table in the H2 DB
 *
 * @author Greg Heiman
 */
@Entity
@Table(name = "\"partner\"")
public class Partner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"id\"")
    private Long partnerId;

    @Column(name = "\"consumer_key\"")
    private String consumerKey;

    @Column(name = "\"consumer_secret\"")
    private String consumerSecret;

    @Column(name = "\"partner_name\"")
    private String partnerName;

    public Partner() {}

    public Partner(String consumerKey, String consumerSecret, String partnerName) {
        this.consumerKey = consumerKey;
        this.consumerSecret = consumerSecret;
        this.partnerName = partnerName;
    }

    public long getPartnerID() {
        return partnerId;
    }

    public void setPartnerId(long partnerId) {
        this.partnerId = partnerId;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public String getConsumerKey() {
        return consumerKey;
    }

    public void setConsumerKey(String consumerKey) {
        this.consumerKey = consumerKey;
    }

    public String getConsumerSecret() {
        return consumerSecret;
    }

    public void setConsumerSecret(String consumerSecret) {
        this.consumerSecret = consumerSecret;
    }

    @Override
    public String toString() {
        return ("Partner:\n"
                + "partnerId: "
                + partnerId
                + "\n"
                + "partnerName: "
                + partnerName
                + "\n"
                + "consumerKey: "
                + consumerKey
                + "\n"
                + "consumerSecret: "
                + consumerSecret);
    }
}
