package com.garmin.partner.common.repositories;

import com.garmin.partner.common.models.SummaryData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface SummaryDataRepository extends JpaRepository<SummaryData, Long> {
    @Query("SELECT new java.lang.Boolean(count(*) = 0) FROM SummaryData WHERE summaryId = ?1")
    public boolean verifyUniqueSummaryId(String summaryId);
}
