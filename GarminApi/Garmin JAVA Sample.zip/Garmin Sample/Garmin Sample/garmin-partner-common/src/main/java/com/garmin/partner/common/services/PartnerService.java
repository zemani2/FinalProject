package com.garmin.partner.common.services;

import java.util.List;

import com.garmin.partner.common.models.Partner;
import com.garmin.partner.common.repositories.PartnerRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PartnerService {
    @Autowired private PartnerRepository partnerRepository;

    public List<Partner> listPartners() {
        return partnerRepository.findAll();
    }

    public Partner findByConsumerKey(Partner partner) {
        return partnerRepository.findByConsumerKey(partner.getConsumerKey());
    }

    public Partner findByPartnerId(Partner partner) {
        return partnerRepository.findByPartnerId(partner.getPartnerID());
    }

    public boolean verifyConsumerKey(Partner partner) {
        return partnerRepository.verifyConsumerKey(partner.getConsumerKey());
    }

    public boolean verifyUniqueConsumerKey(Partner partner) {
        return partnerRepository.verifyUniqueConsumerKey(partner.getConsumerKey());
    }

    public void savePartner(Partner partner) {
        partnerRepository.save(partner);
    }
}
