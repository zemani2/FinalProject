package com.garmin.partner.common;

public final class Consts {
    // The service method
    public static final String PING = "ping/";
    public static final String PUSH = "push/";

    // Endpoints for data
    public static final String ACTIVITIES = "activities";
    public static final String DAILIES = "dailies";
    public static final String THIRD_PARTY_DAILIES = "thirdPartyDailies";
    public static final String EPOCHS = "epochs";
    public static final String SLEEPS = "sleeps";
    public static final String BODYCOMPS = "bodyComps";
    public static final String BLOODPRESSURES = "bloodPressures";
    public static final String ACTIVITYUPDATES = "manuallyUpdatedActivities";
    public static final String MOVEIQ = "moveIQ";
    public static final String PULSEOX = "pulseOx";
    public static final String MCT = "mct";
    public static final String ALL_DAY_RESPIRATION = "allDayRespiration";
    public static final String STRESS = "stress";
    public static final String USERINFO = "userInfo";
    public static final String USERMETRICS = "userMetrics";
    public static final String ACTIVITY_DETAILS = "activityDetails";

    // Other
    public static final String ACTIVITY_FILE_DATA = "activityFiles";
    public static final String ACTIVITY_FILE_DOWNLOAD = "activityFileDownload";
    public static final String UPLOAD_START_TIME = "uploadStartTimeInSeconds";
    public static final String UPLOAD_END_TIME = "uploadEndTimeInSeconds";

    public Consts() {}
}
