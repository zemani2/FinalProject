package com.garmin.partner.common.services;

import com.garmin.partner.common.models.UserAccessToken;
import com.garmin.partner.common.repositories.UserAccessTokenRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserAccessTokenService {
    @Autowired private UserAccessTokenRepository userAccessTokenRepository;

    public List<UserAccessToken> listUserAccessTokens() {
        return userAccessTokenRepository.findAll();
    }

    public UserAccessToken findByUat(UserAccessToken userAccessToken) {
        return userAccessTokenRepository.findByUat(userAccessToken.getUat());
    }

    public boolean verifyUniqueUserAccessToken(UserAccessToken uat) {
        return userAccessTokenRepository.verifyUniqueUserAccessToken(uat.getUat());
    }

    public void saveUserAccessToken(UserAccessToken userAccessToken) {
        userAccessTokenRepository.save(userAccessToken);
    }
}
