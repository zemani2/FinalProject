package com.garmin.partner.common.services;

import com.garmin.partner.common.models.User;
import com.garmin.partner.common.repositories.UserRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired private UserRepository userRepository;
    
    public List<User> listUsers() {
        return userRepository.findAll();
    }

    public void saveUser(User user) {
        userRepository.save(user);
    }

    public User findByUserId(User user) {
        return userRepository.findByUserId(user.getUserId());
    }
}
