package com.garmin.partner.common.models;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Class that holds information about a user entry in the user table in the H2 DB
 *
 * @author Greg Heiman
 */
@Entity
@Table(name = "\"user\"")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "\"id\"")
    private Long userId;

    @Column(name = "\"gcps_user_acct_id\"")
    private String gcpsUserAcctId;

    @Column(name = "\"partner_user_acct_id\"")
    private String partnerUserAcctId;

    @Column(name = "\"partner_id\"")
    private Long partnerId;

    public User() {}

    public User(Long userId, String gcpsUserAcctId, String partnerUserAcctId, Long partnerId) {
        this.userId = userId;
        this.gcpsUserAcctId = gcpsUserAcctId;
        this.partnerUserAcctId = partnerUserAcctId;
        this.partnerId = partnerId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getGcpsUserAcctId() {
        return gcpsUserAcctId;
    }

    public void setGcpcUserAcctId(String gcpsUserAcctId) {
        this.gcpsUserAcctId = gcpsUserAcctId;
    }

    public String getPartnerUserAcctId() {
        return partnerUserAcctId;
    }

    public void setPartnerUserAcctId(String partnerUserAcctId) {
        this.partnerUserAcctId = partnerUserAcctId;
    }

    public long getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(long partnerId) {
        this.partnerId = partnerId;
    }

    /** Generate a random UUID for the partner_user_acct_id field as a placeholder. */
    public static String generatePartnerUserAcctId() {
        return UUID.randomUUID().toString();
    }

    @Override
    public String toString() {
        return ("User:\n"
                + "userId: "
                + userId
                + "\n"
                + "gcpsUserAcctId: "
                + gcpsUserAcctId
                + "\n"
                + "partnerUserAcctId: "
                + partnerUserAcctId
                + "\n"
                + "partnerId: "
                + partnerId
                + "\n");
    }
}
