package com.garmin.partner.common.repositories;

import com.garmin.partner.common.models.UserAccessToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserAccessTokenRepository extends JpaRepository<UserAccessToken, Long> {
    @Query("SELECT u FROM UserAccessToken u WHERE uat=?1")
    public UserAccessToken findByUat(String uat);

    @Query("SELECT new java.lang.Boolean(count(*) = 0) FROM UserAccessToken WHERE uat = ?1")
    public boolean verifyUniqueUserAccessToken(String uat);
}
