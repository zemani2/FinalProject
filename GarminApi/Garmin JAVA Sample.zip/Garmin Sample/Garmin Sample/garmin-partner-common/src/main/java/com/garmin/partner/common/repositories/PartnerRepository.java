package com.garmin.partner.common.repositories;

import com.garmin.partner.common.models.Partner;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface PartnerRepository extends JpaRepository<Partner, Long> {
    public Partner findByConsumerKey(String consumerKey);

    @Query("SELECT p From Partner p Where id=?1")
    public Partner findByPartnerId(Long partnerId);

    @Query("SELECT new java.lang.Boolean(count(*) > 0) FROM Partner WHERE consumerKey = ?1")
    public boolean verifyConsumerKey(String consumerKey);

    @Query("SELECT new java.lang.Boolean(count(*) = 0) FROM Partner WHERE consumerKey = ?1")
    public boolean verifyUniqueConsumerKey(String consumerKey);
}
