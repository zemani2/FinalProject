/*DROP TABLE IF EXISTS "partner" CASCADE;
DROP TABLE IF EXISTS "user" CASCADE;
DROP TABLE IF EXISTS "user_access_token" CASCADE;
DROP TABLE IF EXISTS "summary_data" CASCADE;*/

CREATE TABLE "partner" (
"id"                            bigint(20) PRIMARY KEY auto_increment,
"partner_name"                  varchar(500),
"consumer_key"                  varchar(255),
"consumer_secret"               varchar(255)
);

CREATE TABLE "user" (
  "id"                          bigint(20) PRIMARY KEY auto_increment,
  "gcps_user_acct_id"           varchar(255),
  "partner_user_acct_id"        varchar(255),
  "partner_id"                  bigint(20) NOT NULL
);

CREATE TABLE "user_access_token" (
  "uat"                         varchar(255),
  "uat_secret"                  varchar(255),
  "user_id"                     bigint(20) PRIMARY KEY auto_increment
);

CREATE TABLE "summary_data" (
  "id"                          bigint(20) PRIMARY KEY auto_increment,
  "start_time"                  bigint(20),
  "duration"                    bigint(20),
  "calendar_date"               varchar(50),
  "summary_data_lob"            longblob NOT NULL,
  "summary_domain"              varchar(20),
  "summary_name"                varchar(255),
  "summary_id"                  varchar(255) NOT NULL,
  "user_id"                     bigint(20) NOT NULL
);

ALTER TABLE "user" ADD FOREIGN KEY ("partner_id") REFERENCES "partner" ("id");

ALTER TABLE "user_access_token" ADD FOREIGN KEY ("user_id") REFERENCES "user" ("id");

ALTER TABLE "summary_data" ADD FOREIGN KEY ("user_id") REFERENCES "user" ("id");

