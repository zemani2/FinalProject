# Garmin Partner Common
Common library for all modules.
