package com.garmin.partner.userapi.controller;

import com.garmin.partner.common.models.User;
import com.garmin.partner.common.models.UserAccessToken;
import com.garmin.partner.common.services.UserAccessTokenService;
import com.garmin.partner.common.services.UserService;
import com.garmin.partner.userapi.UserApiService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controls the user endpoints
 *
 * @author Greg Heiman
 */
@RestController
@EnableAutoConfiguration
@RequestMapping("/user")
public class UserApiController {
    private static final Logger log = LoggerFactory.getLogger(UserApiController.class);

    @Autowired
    private UserService userService;
    @Autowired
    private UserAccessTokenService userAccessTokenService;
    @Autowired
    private UserApiService userApiService;

    private UserAccessToken uat = new UserAccessToken();
    private User user = new User();
    
    /** Test endpoint for the user service. Simply returns a message. */
    @RequestMapping(value = "/test", method = RequestMethod.GET)
    public String handleTestEndpoint() {
        return "Hello. This test endpoint is working";
    }

    /**
     * Deregisters the user from the service. The partner will no longer
     * recieve any notifications from the Garmin API regarding the user.
     * The UAT is provided in the OAuth header. On successful response
     * Garmin will return 204. This program will also return 204 on success.
     *
     * @param userAccessToken: a valid userAccessToken for the user that
     * wants to deregister.
     * @return a {@link ResponseEntity} with status 204 on success 400 otherwise.
     */
    @RequestMapping(value = "/deregister", method = RequestMethod.GET)
    public ResponseEntity<String> handleDegregistration(@RequestParam String userAccessToken) {
        // Set the uat from the request param
        uat.setUat(userAccessToken);
        // Find the rest of the UAT info
        uat = userAccessTokenService.findByUat(uat);

        return userApiService.deregisterUser(uat);
    }

    /**
     * Gets the unique Garmin API ID for the user. This user ID will persist
     * across multiple UATs. There is no reason to pass this user ID back to 
     * the Garmin API as the Garmin API always uses UATs for authentication.
     * The UAT for which to retrive the User ID will be provided in the OAuth header.
     */
    @RequestMapping(value = "/getUserId", method = RequestMethod.GET)
    public ResponseEntity<String> handleGetGarminUserId(@RequestParam String userAccessToken) {
        // Set the uat from the request param
        uat.setUat(userAccessToken);
        // Find the rest of the UAT info
        uat = userAccessTokenService.findByUat(uat);

        return userApiService.retrieveUserId(uat);
    }
}
