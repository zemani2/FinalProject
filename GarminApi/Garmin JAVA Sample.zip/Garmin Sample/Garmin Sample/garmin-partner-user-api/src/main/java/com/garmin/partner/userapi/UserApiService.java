package com.garmin.partner.userapi;

import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.garmin.partner.common.models.Partner;
import com.garmin.partner.common.models.User;
import com.garmin.partner.common.models.UserAccessToken;
import com.garmin.partner.common.services.PartnerService;
import com.garmin.partner.common.services.UserService;
import com.garmin.partner.oauth.OAuthImpl;
import com.github.scribejava.core.model.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service to manage the user endpoints in the Garmin API.
 * 
 * @author Greg Heiman
 */
@Service
@Transactional
public class UserApiService {
    private static final Logger log = LoggerFactory.getLogger(UserApiService.class);
    @Autowired
    private OAuthImpl oAuthImpl;
    @Autowired
    private PartnerService partnerService;
    @Autowired
    private UserService userService;

    @Value("${deregistration.url}")
    private String deregistrationUrl;
    @Value("${retrieveuserid.url}")
    private String retrieveuserIdUrl;

    /**
     * Create and attach an OAuth header to the request to the Garmin API. Then send
     * the request to Garmin.
     * 
     * @return a {@link ResponseEntity} with status 204 on success 400 otherwise.
     */
    public ResponseEntity<String> deregisterUser(UserAccessToken uat) {
        createOAuthDeregisterRequest(uat);

        try {
            return sendDeregisterRequestToGarmin();
        } catch (Exception e) {
            log.error("There was an error in sending the deregistration request to Garmin.\n" + e.getMessage());
            return new ResponseEntity<String>("There was an error in deregistering the user.",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Retrieve the User Id from the Garmin API. The UAT from which to retrieve the user id
     * will be in the OAuth header.
     *
     * @return {@link ResponseEntity} with status 204 if successful, 400 otherwise
     */    
    public ResponseEntity<String> retrieveUserId(UserAccessToken uat) {
        createOAuthRetrieveUserIdRequest(uat);
    
        String userId = null;
        try {
            userId = parseUserIdFromJson(sendRetrieveUserIdRequestToGarmin());
        } catch (JsonProcessingException je) {
            log.error("There was an error handling the JSON returned from Garmin.\n" + je.getMessage());
        } catch (ExecutionException | IOException e) {
            log.error("There was an error sending the retrieve user ID request to Garmin.\n" + e.getMessage());
        }
    
        if (userId != null) {
            return new ResponseEntity<String>("Found user Id " + userId + "<br>" + "for " + "UAT: " + uat.toString() + ".", HttpStatus.OK);
        } else {
            return new ResponseEntity<String>("User id is null. Most likely an error in fetching the user id.",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    

    /**
     * Create the OAuth request for the retrieve user id endpoint.
     */
    private void createOAuthRetrieveUserIdRequest(UserAccessToken uat) {
        Partner partner = new Partner();
        User user = new User();

        try {
            // Set the user ID from the UAT
            user.setUserId(uat.getUserId());
            // Find the rest of the User information
            user = userService.findByUserId(user);

            // Create the OAuth service
            partner.setPartnerId(user.getPartnerId());
            partner = partnerService.findByPartnerId(partner);
        } catch (NullPointerException npe) {
            log.error("There was an error setting up the models for the user service endpoints. "
                    + "Ensure that user is present in DB.\n" + npe.getMessage());
        }

        // Create the OAuth service
        oAuthImpl.setService(partner.getConsumerKey(), partner.getConsumerSecret());

        // Create the OAuth request
        oAuthImpl.createOAuthAccessToken(uat.getUat(), uat.getUatSecret());
        oAuthImpl.createOAuthGetRequest(retrieveuserIdUrl);

        oAuthImpl.getService().signRequest(oAuthImpl.getAccessToken(), oAuthImpl.getRequest());
    }

    /**
     * Create the Oauth request for the user dregistration endpoint
     */
    private void createOAuthDeregisterRequest(UserAccessToken uat) {
        Partner partner = new Partner();
        User user = new User();

        try {
            // Set the user ID from the UAT
            user.setUserId(uat.getUserId());
            // Find the rest of the User information
            user = userService.findByUserId(user);

            // Create the OAuth service
            partner.setPartnerId(user.getPartnerId());
            partner = partnerService.findByPartnerId(partner);
        } catch (NullPointerException npe) {
            log.error("There was an error setting up the models for the user service endpoints. "
                    + "Ensure that user is present in DB.\n" + npe.getMessage());
        }

        // Create the OAuth service
        oAuthImpl.setService(partner.getConsumerKey(), partner.getConsumerSecret());

        // Create the OAuth request
        oAuthImpl.createOAuthAccessToken(uat.getUat(), uat.getUatSecret());
        oAuthImpl.createOAuthDeleteRequest(deregistrationUrl);

        oAuthImpl.getService().signRequest(oAuthImpl.getAccessToken(), oAuthImpl.getRequest());
    }

    /**
     * Send the deregistration request to the Garmin API.
     *
     * @return a {@link ResponseEntity} with status 204 if successful, 400 otherwise
     */
    private ResponseEntity<String> sendDeregisterRequestToGarmin()
        throws RuntimeException, IOException, ExecutionException, NullPointerException {
        // Send the request to the callback URL
        try {
            log.info("Sending user api request");
            final Response response = oAuthImpl.getService().execute(oAuthImpl.getRequest());

            if (response.getCode() == 204) {
                log.info("Recieved 204 response from Garmin for deregistering user.");
                return new ResponseEntity<String>("Recieved success response from Garmin for user api request.",
                        HttpStatus.NO_CONTENT);
            } else {
                log.warn("Did NOT recieve 204 response from Garmin. Recieved: " + response.getCode());
                return new ResponseEntity<String>("Recieved no success response from Garmin for user api request.",
                                                  HttpStatus.BAD_REQUEST);
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(ex);
        } catch (NullPointerException npe) {
            log.error("There was a null pointer exception when sending the deregistration request to Garmin.\n"
                    + npe.getMessage());
            return new ResponseEntity<String>("There was an error sending the deregistration request to Garmin.",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Send the retrieve user Id request to the Garmin API.
     *
     * @return a {@link String} containing the body of the Json returned from Garmin
     */
    private String sendRetrieveUserIdRequestToGarmin() throws ExecutionException, RuntimeException, IOException {
        // Send the request to the callback URL
        try {
            log.info("Sending response to callback url");
            final Future<Response> response = oAuthImpl.getService().executeAsync(oAuthImpl.getRequest());
            // Return the body of the request which houses the returned data from
            // Garmin
            while (!response.isDone()) {
                log.info("Fetching response from Garmin API...");
                Thread.sleep(300);
            }

            if (response.get().getBody().equals("[]") || response.get().getBody().isEmpty()
                    || response.get().getBody().length() == 0 || response.get().getBody().isBlank())
                throw new IOException("No body returned from callback URL");
            else {
                log.info("Fetched response from Garmin API.");
                return response.get().getBody();
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new RuntimeException(ex);
        }

    }

    /**
     * Parse the userId field from the Json returned from Garmin.
     *
     * @param retrieveUserIdResponse: the response from the retrieve user id endpoint
     * @return the user Id string that was parsed from the JSON
     */
    private String parseUserIdFromJson(String retrieveUserIdResponse)
            throws JsonMappingException, JsonProcessingException, IOException {
        JsonNode parent = new ObjectMapper().readTree(retrieveUserIdResponse);
        if (parent.has("userId")) {
            return parent.path("userId").asText();
        } else {
            throw new IOException("Could not find field userId to parse the user Id from.");
        }
    }
}
