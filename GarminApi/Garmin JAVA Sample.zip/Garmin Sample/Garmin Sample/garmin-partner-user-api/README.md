# User Service Sample
This module is designed to give partners a sample implementation for the user service endpoints 
that the Garmin API offers.

## Requirements
    * A valid test consumer set up at [developerportal.garmin.com](https://developerportal.garmin.com)
    * A valid test account set up at [connectest.garmin.com](https://connecttest.garmin.com)

## Usage
    1. Run `mvn clean package` in the parent directory to build all of the modules.
    
    2. Run `java -jar garmin-partner-user-api/target/userapi-______.jar` in order to run the 
    user service module.
    
    3. Navigate to `/consumer/setUpNewPartner` and create a new partner entry in the DB.
    
    4. Navigate to `/auth/requestToken?consumer_key=` in order to set up a valid user for the partner you just placed
    into the DB (`consumer_key=` is the consumer key that you entered in during the new partner set up process)
    * If running on localhost the port number is 9000 
    
    5. Navigate to one of the following user service endpoints:
    * `/user/getUserId?userAccessToken=` Retrieves the user ID from Garmin for the provided User Access Token
    * `/user/deregister?userAccessToken=` Deregisters the user access token from the consumer it is attached to.
